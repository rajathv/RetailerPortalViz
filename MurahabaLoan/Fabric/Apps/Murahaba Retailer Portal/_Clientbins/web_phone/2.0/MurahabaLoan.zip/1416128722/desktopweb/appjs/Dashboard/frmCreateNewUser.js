define("Dashboard/frmCreateNewUser", function() {
    return function(controller) {
        function addWidgetsfrmCreateNewUser() {
            this.setDefaultUnit(kony.flex.DP);
            var HeaderComponentPostLogin = new com.HeaderComponentPostLogin({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100px",
                "id": "HeaderComponentPostLogin",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slnflxbottomGreyBorder",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "MurahabaLoan",
                "overrides": {
                    "HeaderComponentPostLogin": {
                        "height": "100px",
                        "zIndex": 3
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var leftpane = new com.leftpane({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "924px",
                "id": "leftpane",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "100px",
                "width": "300px",
                "zIndex": 3,
                "appName": "MurahabaLoan",
                "overrides": {
                    "flxCreateNewUser": {
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxHomePage": {
                        "top": "150px",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxLine1": {
                        "isVisible": false
                    },
                    "flxLine2": {
                        "isVisible": true
                    },
                    "lblCreateNewUser": {
                        "isVisible": true,
                        "left": "48dp",
                        "top": "viz.val_cleared"
                    },
                    "lblHomePage": {
                        "left": "48dp"
                    },
                    "leftpane": {
                        "height": "924px",
                        "top": "100px",
                        "width": "300px",
                        "zIndex": 3
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxRightPane = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "924px",
                "id": "flxRightPane",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "300px",
                "isModalContainer": false,
                "skin": "sknflxbggrey",
                "top": "100px",
                "width": "78%",
                "zIndex": 2,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightPane.setDefaultUnit(kony.flex.DP);
            var imgBg = new kony.ui.Image2({
                "height": "1000px",
                "id": "imgBg",
                "isVisible": false,
                "left": "50px",
                "skin": "slImage",
                "src": "background1x.png",
                "top": "-239dp",
                "width": "1156px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "855px",
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxWhiteBGBorderpx30",
                "top": "50px",
                "width": "92%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxTopContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxTopContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopContent.setDefaultUnit(kony.flex.DP);
            var lblRetailPrtner = new kony.ui.Label({
                "id": "lblRetailPrtner",
                "isVisible": true,
                "left": "70px",
                "skin": "sknlbl18pxCalibriGrey",
                "text": "RETAIL PATNER PORTAL",
                "top": "60px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLoginContenet = new kony.ui.Label({
                "id": "lblLoginContenet",
                "isVisible": true,
                "left": "70px",
                "skin": "sknlbl2c3d73px22bold",
                "text": "Once user record is created, the user ID will be sent to employee’s email address and temporary password will be sent to employee’s mobile number.",
                "top": "90px",
                "width": "80%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTopContent.add(lblRetailPrtner, lblLoginContenet);
            var flxUserDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "586dp",
                "id": "flxUserDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxGreyBGBorder30PX",
                "top": "246dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserDetails.setDefaultUnit(kony.flex.DP);
            var flxLine1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "72dp",
                "id": "flxLine1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "zIndex": 20,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxLine1.setDefaultUnit(kony.flex.DP);
            var flxUsername = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxUsername",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "45%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxUsername.setDefaultUnit(kony.flex.DP);
            var lblUsername = new kony.ui.Label({
                "id": "lblUsername",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px18",
                "text": "USER NAME",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtUsername = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtUsername",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Enter user name",
                "secureTextEntry": false,
                "skin": "skntxtboxwhiterounded",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxUsername.add(lblUsername, txtUsername);
            var flxRole = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxRole",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "10px",
                "skin": "slFbox",
                "top": "0px",
                "width": "45%",
                "zIndex": 20,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxRole.setDefaultUnit(kony.flex.DP);
            var lblRole = new kony.ui.Label({
                "id": "lblRole",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px18",
                "text": "ROLE",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtRole = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtRole",
                "isVisible": false,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Please select role from drop down",
                "secureTextEntry": false,
                "skin": "skntxtboxwhiterounded",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var flxRoleSelection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxRoleSelection",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknwhitebgroundedcorner",
                "top": "5dp",
                "width": "354dp",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxRoleSelection.setDefaultUnit(kony.flex.DP);
            var lblRoleSelection = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblRoleSelection",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknlbl18px6A7E9B",
                "text": "Please select role from drop down",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgArrow = new kony.ui.Image2({
                "centerY": "50%",
                "height": "15dp",
                "id": "imgArrow",
                "isVisible": true,
                "right": "20dp",
                "skin": "slImage",
                "src": "downarrow1x.png",
                "top": "15dp",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRoleSelection.add(lblRoleSelection, imgArrow);
            var flxSegRole = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0",
                "clipBounds": false,
                "height": "150px",
                "id": "flxSegRole",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sKnflx2C3D73ShadowRoundedBottom",
                "top": "0%",
                "width": "340px",
                "zIndex": 20,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegRole.setDefaultUnit(kony.flex.DP);
            var segRole = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblUserName": "Sale Representative"
                }, {
                    "lblUserName": "Sale Person"
                }],
                "groupCells": false,
                "height": "95%",
                "id": "segRole",
                "isVisible": true,
                "left": "8dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "segRoundedCornerpx30",
                "rowTemplate": "flxUserList",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxUserList": "flxUserList",
                    "lblUserName": "lblUserName"
                },
                "width": "95.92%",
                "zIndex": 20,
                "appName": "MurahabaLoan"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegRole.add(segRole);
            flxRole.add(lblRole, txtRole, flxRoleSelection, flxSegRole);
            flxLine1.add(flxUsername, flxRole);
            var flxLine2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "72dp",
                "id": "flxLine2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "50dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxLine2.setDefaultUnit(kony.flex.DP);
            var flxPhoneNo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxPhoneNo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "45%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhoneNo.setDefaultUnit(kony.flex.DP);
            var lblphone = new kony.ui.Label({
                "id": "lblphone",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px18",
                "text": "PHONE NUMBER",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPhoneGroup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxPhoneGroup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "flxsknLblasTxtLook",
                "top": "10dp",
                "width": "354px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhoneGroup.setDefaultUnit(kony.flex.DP);
            var lblCountryCode = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCountryCode",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl2c3d7320px",
                "text": "+966",
                "top": "0",
                "width": "50px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtPhoneNo = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtPhoneNo",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "50dp",
                "maxTextLength": 10,
                "placeholder": "Enter Phone Number",
                "secureTextEntry": false,
                "skin": "skntxtboxwhiterounded",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0px",
                "width": "300px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxPhoneGroup.add(lblCountryCode, txtPhoneNo);
            flxPhoneNo.add(lblphone, flxPhoneGroup);
            var flxEmail = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxEmail",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "10px",
                "skin": "slFbox",
                "top": "0px",
                "width": "45%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmail.setDefaultUnit(kony.flex.DP);
            var CopylblRole0cfa0b734f06445 = new kony.ui.Label({
                "id": "CopylblRole0cfa0b734f06445",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px18",
                "text": "EMAIL",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtEmail = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtEmail",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "example@mail.com",
                "secureTextEntry": false,
                "skin": "skntxtboxwhiterounded",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxEmail.add(CopylblRole0cfa0b734f06445, txtEmail);
            flxLine2.add(flxPhoneNo, flxEmail);
            var flxuserid = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "72dp",
                "id": "flxuserid",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "50dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxuserid.setDefaultUnit(kony.flex.DP);
            var CopyflxUsername0e27727ade06142 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "CopyflxUsername0e27727ade06142",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "45%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxUsername0e27727ade06142.setDefaultUnit(kony.flex.DP);
            var CopylblUsername0d7cd8edd184b4c = new kony.ui.Label({
                "id": "CopylblUsername0d7cd8edd184b4c",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px18",
                "text": "USER ID",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtUserId = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtUserId",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Enter user ID",
                "secureTextEntry": false,
                "skin": "skntxtboxwhiterounded",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            CopyflxUsername0e27727ade06142.add(CopylblUsername0d7cd8edd184b4c, txtUserId);
            flxuserid.add(CopyflxUsername0e27727ade06142);
            var btnCreateUser = new kony.ui.Button({
                "centerX": "50%",
                "height": "50dp",
                "id": "btnCreateUser",
                "isVisible": true,
                "skin": "sknbtn898A8DRounded",
                "text": "Create User",
                "top": "51dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUserDetails.add(flxLine1, flxLine2, flxuserid, btnCreateUser);
            var flxsubheader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "50dp",
                "id": "flxsubheader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "170dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxsubheader.setDefaultUnit(kony.flex.DP);
            var Label0af7b33c672b04e = new kony.ui.Label({
                "centerX": "50%",
                "id": "Label0af7b33c672b04e",
                "isVisible": true,
                "skin": "sknlbl2c3d73px22",
                "text": "USER DETAILS",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUserLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "5dp",
                "id": "flxUserLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflx2c3d73FillLine",
                "top": "5dp",
                "width": "15%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserLine.setDefaultUnit(kony.flex.DP);
            flxUserLine.add();
            flxsubheader.add(Label0af7b33c672b04e, flxUserLine);
            flxContent.add(flxTopContent, flxUserDetails, flxsubheader);
            var flxUserNotFound = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "51.73%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "460px",
                "id": "flxUserNotFound",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxBgWhite30PxRadius",
                "top": "0dp",
                "width": "500px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserNotFound.setDefaultUnit(kony.flex.DP);
            var CopylblRetailPater0e7f1c5d87bf444 = new kony.ui.Label({
                "centerX": "50%",
                "id": "CopylblRetailPater0e7f1c5d87bf444",
                "isVisible": true,
                "skin": "sknlbl20pxCalibriGrey",
                "text": "RETAIL PATNER PORTAL",
                "top": "15%",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyflxLineSection0a8165898f2df4f = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "3px",
                "id": "CopyflxLineSection0a8165898f2df4f",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxRedLine",
                "top": "21%",
                "width": "33px",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxLineSection0a8165898f2df4f.setDefaultUnit(kony.flex.DP);
            CopyflxLineSection0a8165898f2df4f.add();
            var CopylblAcknowledgeMsg0i178658825624e = new kony.ui.Label({
                "centerX": "50%",
                "id": "CopylblAcknowledgeMsg0i178658825624e",
                "isVisible": true,
                "skin": "sknlbl2c3d7335pxBold",
                "text": "user \n sucessfully created",
                "top": "180dp",
                "width": "50%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyflxBtn0h178ee0be72f40 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "50dp",
                "clipBounds": false,
                "height": "100dp",
                "id": "CopyflxBtn0h178ee0be72f40",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxBtn0h178ee0be72f40.setDefaultUnit(kony.flex.DP);
            var CopyflxSep0a4bf1c9d611a4c = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "2px",
                "id": "CopyflxSep0a4bf1c9d611a4c",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxline6A7E9B",
                "top": "5%",
                "width": "274px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxSep0a4bf1c9d611a4c.setDefaultUnit(kony.flex.DP);
            CopyflxSep0a4bf1c9d611a4c.add();
            var btnContinue = new kony.ui.Button({
                "centerX": "49.99%",
                "height": "50dp",
                "id": "btnContinue",
                "isVisible": true,
                "left": "0",
                "skin": "sknbtnNoBg2C3D73px24",
                "text": "continue",
                "top": "35%",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxBtn0h178ee0be72f40.add(CopyflxSep0a4bf1c9d611a4c, btnContinue);
            flxUserNotFound.add(CopylblRetailPater0e7f1c5d87bf444, CopyflxLineSection0a8165898f2df4f, CopylblAcknowledgeMsg0i178658825624e, CopyflxBtn0h178ee0be72f40);
            flxRightPane.add(imgBg, flxContent, flxUserNotFound);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "HeaderComponentPostLogin": {
                    "height": "100px",
                    "zIndex": 3
                },
                "leftpane.flxCreateNewUser": {
                    "layoutType": kony.flex.FREE_FORM
                },
                "leftpane.flxHomePage": {
                    "top": "150px",
                    "layoutType": kony.flex.FREE_FORM
                },
                "leftpane.lblCreateNewUser": {
                    "left": "48dp",
                    "top": ""
                },
                "leftpane.lblHomePage": {
                    "left": "48dp"
                },
                "leftpane": {
                    "height": "924px",
                    "top": "100px",
                    "width": "300px",
                    "zIndex": 3
                }
            }
            this.add(HeaderComponentPostLogin, leftpane, flxRightPane);
        };
        return [{
            "addWidgets": addWidgetsfrmCreateNewUser,
            "enabledForIdleTimeout": false,
            "id": "frmCreateNewUser",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "preShow": function(eventobject) {
                controller.AS_Form_da5ee9503e7845febeacf55ee1ed4126(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "MurahabaLoan"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});