define("Authentication/frmOtpValidation", function() {
    return function(controller) {
        function addWidgetsfrmOtpValidation() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknflxscrollbggrey",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "10%",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var HeaderComponent = new com.HeaderComponent({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "HeaderComponent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan",
                "overrides": {
                    "HeaderComponent": {
                        "height": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(HeaderComponent);
            var flxContainerSection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "613px",
                "id": "flxContainerSection",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sKnflxGreyBorder25px",
                "top": "157px",
                "width": "90%",
                "zIndex": 2,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxContainerSection.setDefaultUnit(kony.flex.DP);
            var flxLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "45%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var lblRetailPrtner = new kony.ui.Label({
                "id": "lblRetailPrtner",
                "isVisible": true,
                "left": "80px",
                "skin": "sknlbl18pxCalibriGrey",
                "text": "RETAIL PATNER PORTAL",
                "top": "60px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLoginContenet = new kony.ui.Label({
                "id": "lblLoginContenet",
                "isVisible": true,
                "left": "80px",
                "skin": "sknlbl2c3d7335pxBold",
                "text": "We have sent a verification code to the phone number ending in ******989",
                "top": "90px",
                "width": "500px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPasswordInfo = new kony.ui.Label({
                "id": "lblPasswordInfo",
                "isVisible": true,
                "left": "90px",
                "skin": "sknlbl18px6A7E9B",
                "text": "To verify your account please enter it below. Your code will expire in 3:00 minutes. ",
                "top": "170px",
                "width": "400px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "48px",
                "id": "flxLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "80px",
                "isModalContainer": false,
                "skin": "sknflxRedLine",
                "top": "170px",
                "width": "3px",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxLine.setDefaultUnit(kony.flex.DP);
            flxLine.add();
            flxLeft.add(lblRetailPrtner, lblLoginContenet, lblPasswordInfo, flxLine);
            var flxRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "478px",
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "90px",
                "skin": "sknflxGreyBGBorder30PX",
                "top": "60px",
                "width": "530px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxpasswordbox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxpasswordbox",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "88px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "125px",
                "width": "354px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxpasswordbox.setDefaultUnit(kony.flex.DP);
            var flxOTP = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "35dp",
                "id": "flxOTP",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxOTP.setDefaultUnit(kony.flex.DP);
            var txtotp1 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "skntxtboxbottomborder",
                "height": "40dp",
                "id": "txtotp1",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "maxTextLength": 1,
                "secureTextEntry": false,
                "skin": "skntxtboxbottomborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0px",
                "width": "50px",
                "zIndex": 3
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var txtotp2 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "skntxtboxbottomborder",
                "height": "40dp",
                "id": "txtotp2",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "10px",
                "maxTextLength": 1,
                "secureTextEntry": false,
                "skin": "skntxtboxbottomborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0px",
                "width": "50px",
                "zIndex": 3
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var txtotp3 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "skntxtboxbottomborder",
                "height": "40dp",
                "id": "txtotp3",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "10px",
                "maxTextLength": 1,
                "secureTextEntry": false,
                "skin": "skntxtboxbottomborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0px",
                "width": "50px",
                "zIndex": 3
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var txtotp4 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "skntxtboxbottomborder",
                "height": "40dp",
                "id": "txtotp4",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "10px",
                "maxTextLength": 1,
                "secureTextEntry": false,
                "skin": "skntxtboxbottomborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0px",
                "width": "50px",
                "zIndex": 3
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var txtotp5 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "skntxtboxbottomborder",
                "height": "40dp",
                "id": "txtotp5",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "10px",
                "maxTextLength": 1,
                "secureTextEntry": false,
                "skin": "skntxtboxbottomborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0px",
                "width": "50px",
                "zIndex": 3
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var txtotp6 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "skntxtboxbottomborder",
                "height": "40dp",
                "id": "txtotp6",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "10px",
                "maxTextLength": 1,
                "secureTextEntry": false,
                "skin": "skntxtboxbottomborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0px",
                "width": "50px",
                "zIndex": 3
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxOTP.add(txtotp1, txtotp2, txtotp3, txtotp4, txtotp5, txtotp6);
            var lblnewcode = new kony.ui.Label({
                "id": "lblnewcode",
                "isVisible": false,
                "left": "0",
                "skin": "sknlbl18px2D3E71",
                "text": "Send a new code",
                "top": "10dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnReSend = new kony.ui.Button({
                "id": "btnReSend",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknbtnNoBg2C3D73px18",
                "text": "Send a new code",
                "top": "10dp",
                "width": "200dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblotpresend = new kony.ui.Label({
                "id": "lblotpresend",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl18px6A7E9B",
                "text": "02 : 59",
                "top": "5dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxpasswordbox.add(flxOTP, lblnewcode, btnReSend, lblotpresend);
            var flxError = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxError",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "88px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "230px",
                "width": "354px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxError.setDefaultUnit(kony.flex.DP);
            var lblError1 = new kony.ui.Label({
                "id": "lblError1",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblFF4D56px13ErrorMsg",
                "text": "Wrong OTP Entered.",
                "top": "0dp",
                "width": "300px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblError2 = new kony.ui.Label({
                "id": "lblError2",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblFF4D56px13ErrorMsg",
                "text": "Please enter correct OTP code",
                "top": "5dp",
                "width": "300px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblError3 = new kony.ui.Label({
                "id": "lblError3",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblFF4D56px13ErrorMsg",
                "text": "Don't receive a code? Send a new one",
                "top": "5dp",
                "width": "300px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxError.add(lblError1, lblError2, lblError3);
            var flxAction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxAction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "350px",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxAction.setDefaultUnit(kony.flex.DP);
            var btnContinue = new kony.ui.Button({
                "bottom": 10,
                "height": "50dp",
                "id": "btnContinue",
                "isVisible": true,
                "right": "70px",
                "skin": "sknbtn2c3d73Rounded18px",
                "text": "Continue    >",
                "top": "0px",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBack = new kony.ui.Button({
                "centerY": "50%",
                "height": "42px",
                "id": "btnBack",
                "isVisible": true,
                "left": "88px",
                "skin": "sknbtnbackimg",
                "top": "0dp",
                "width": "42px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAction.add(btnContinue, btnBack);
            flxRight.add(flxpasswordbox, flxError, flxAction);
            flxContainerSection.add(flxLeft, flxRight);
            var imgBackground = new kony.ui.Image2({
                "height": "1128px",
                "id": "imgBackground",
                "isVisible": true,
                "right": "-5%",
                "skin": "slImage",
                "src": "background1x.png",
                "top": "-239px",
                "width": "1156px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMain.add(flxHeader, flxContainerSection, imgBackground);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "HeaderComponent": {
                    "height": "100%"
                }
            }
            this.add(flxMain);
        };
        return [{
            "addWidgets": addWidgetsfrmOtpValidation,
            "enabledForIdleTimeout": false,
            "id": "frmOtpValidation",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_g31d057413aa4ad18e6f4dd821482819,
            "preShow": function(eventobject) {
                controller.AS_Form_acd49ad4da3c4d4f86ad97c28fd759fd(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "MurahabaLoan"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});