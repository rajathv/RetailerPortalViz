define("Dashboard/frmGenerateVoucherMI", function() {
    return function(controller) {
        function addWidgetsfrmGenerateVoucherMI() {
            this.setDefaultUnit(kony.flex.DP);
            var HeaderComponentPostLogin = new com.HeaderComponentPostLogin({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100px",
                "id": "HeaderComponentPostLogin",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slnflxbottomGreyBorder",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "MurahabaLoan",
                "overrides": {
                    "HeaderComponentPostLogin": {
                        "height": "100px",
                        "zIndex": 3
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var leftpane = new com.leftpane({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "924px",
                "id": "leftpane",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "100px",
                "width": "300px",
                "zIndex": 3,
                "appName": "MurahabaLoan",
                "overrides": {
                    "flxCreateNewUser": {
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxHomePage": {
                        "top": "150px",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxLine1": {
                        "isVisible": false
                    },
                    "flxLine2": {
                        "isVisible": false
                    },
                    "flxLine5": {
                        "isVisible": true
                    },
                    "lblCreateNewUser": {
                        "isVisible": true,
                        "left": "48dp",
                        "top": "viz.val_cleared"
                    },
                    "lblHomePage": {
                        "left": "48dp"
                    },
                    "leftpane": {
                        "height": "924px",
                        "top": "100px",
                        "width": "300px",
                        "zIndex": 3
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxRightPane = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "924px",
                "id": "flxRightPane",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "300px",
                "isModalContainer": false,
                "skin": "sknflxbggrey",
                "top": "100px",
                "width": "78%",
                "zIndex": 2,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightPane.setDefaultUnit(kony.flex.DP);
            var imgBg = new kony.ui.Image2({
                "height": "100%",
                "id": "imgBg",
                "isVisible": true,
                "right": 0,
                "skin": "slImage",
                "src": "background1x.png",
                "top": "-10%",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxGenerateVoucher = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "900px",
                "id": "flxGenerateVoucher",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1066px",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxGenerateVoucher.setDefaultUnit(kony.flex.DP);
            var flxTopHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTopHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopHeader.setDefaultUnit(kony.flex.DP);
            var lblRetailPartnerPortal = new kony.ui.Label({
                "id": "lblRetailPartnerPortal",
                "isVisible": true,
                "left": "70px",
                "skin": "sknlblF0ECE9px40",
                "text": "RETAIL PATNER PORTAL",
                "top": "90px",
                "width": "521px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var brwsExcel = new kony.ui.Browser({
                "detectTelNumber": true,
                "enableZoom": false,
                "height": "10dp",
                "id": "brwsExcel",
                "isVisible": true,
                "left": "0dp",
                "setAsContent": false,
                "requestURLConfig": {
                    "URL": "convertJsonToExcel.html",
                    "requestMethod": constants.BROWSER_REQUEST_METHOD_GET
                },
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxTopHeader.add(lblRetailPartnerPortal, brwsExcel);
            var flxSearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "70px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20%",
                "width": "490px",
                "zIndex": 2,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearch.setDefaultUnit(kony.flex.DP);
            var txtSearchVoucher = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtSearchVoucher",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "maxTextLength": 13,
                "placeholder": "Please enter Mobile Number",
                "secureTextEntry": false,
                "skin": "skltxtNoBg1Rounded2c3d73",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "490px",
                "zIndex": 2
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false
            });
            var flxSearchIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "50%",
                "id": "flxSearchIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "5%",
                "skin": "slFbox",
                "top": "0",
                "width": "10%",
                "zIndex": 2,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchIcon.setDefaultUnit(kony.flex.DP);
            var imgSearch = new kony.ui.Image2({
                "height": "100%",
                "id": "imgSearch",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "search1x.png",
                "top": "0dp",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchIcon.add(imgSearch);
            flxSearch.add(txtSearchVoucher, flxSearchIcon);
            var flxSegmentSearchList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "470px",
                "id": "flxSegmentSearchList",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "70px",
                "isModalContainer": false,
                "skin": "sKnflx2C3D73ShadowRoundedBottom",
                "top": "25%",
                "width": "490px",
                "zIndex": 10,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegmentSearchList.setDefaultUnit(kony.flex.DP);
            var segVouchers = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }],
                "groupCells": false,
                "height": "95.53%",
                "id": "segVouchers",
                "isVisible": true,
                "left": "8dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "segRoundedCornerpx30",
                "rowTemplate": "flxUserList",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "e4e4e433",
                "separatorRequired": true,
                "showScrollbars": false,
                "top": "11dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxUserList": "flxUserList",
                    "lblUserName": "lblUserName"
                },
                "width": "95.92%",
                "appName": "MurahabaLoan"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegmentSearchList.add(segVouchers);
            var flxGroupCalender = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "14.44%",
                "id": "flxGroupCalender",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30%",
                "width": "92%",
                "zIndex": 2,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxGroupCalender.setDefaultUnit(kony.flex.DP);
            var CalenderStartDate = new kony.ui.Calendar({
                "calendarIcon": "dropdown2x.png",
                "dateComponents": [null, null, null],
                "dateFormat": "dd/MM/yyyy",
                "hour": 0,
                "id": "CalenderStartDate",
                "isVisible": true,
                "left": "20dp",
                "minutes": 0,
                "placeholder": "voucher generate start date",
                "seconds": 0,
                "skin": "skncal6A7E9Bpx16",
                "top": "35%",
                "validStartDate": [1, 1, 2001],
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "25%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            var CalenderEndDate = new kony.ui.Calendar({
                "calendarIcon": "dropdown2x.png",
                "dateComponents": [null, null, null, 0, 0, 0],
                "dateFormat": "dd/MM/yyyy",
                "height": "40dp",
                "id": "CalenderEndDate",
                "isVisible": true,
                "left": "35%",
                "placeholder": "voucher generate end date",
                "skin": "skncal6A7E9Bpx16",
                "top": "35.00%",
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "25%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            var flxVoucherStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxVoucherStatus",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "68%",
                "isModalContainer": false,
                "skin": "sknflxWhiteBG2C3D7330PxRadius",
                "top": "35%",
                "width": "25%",
                "zIndex": 15,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxVoucherStatus.setDefaultUnit(kony.flex.DP);
            var btnSelectStatus = new kony.ui.Button({
                "height": "40dp",
                "id": "btnSelectStatus",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknbtntrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 20
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVoucherSts = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblVoucherSts",
                "isVisible": true,
                "skin": "sknlbl18px6A7E9B",
                "text": "Voucher Status",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImgDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxImgDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20px",
                "skin": "slFbox",
                "top": "0dp",
                "width": "15%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgDropdown.setDefaultUnit(kony.flex.DP);
            var imgDropdown = new kony.ui.Image2({
                "height": "100%",
                "id": "imgDropdown",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "dropdown3x.png",
                "top": "0dp",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgDropdown.add(imgDropdown);
            flxVoucherStatus.add(btnSelectStatus, lblVoucherSts, flxImgDropdown);
            var flxSegStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0",
                "clipBounds": false,
                "height": "150px",
                "id": "flxSegStatus",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "68.50%",
                "isModalContainer": false,
                "skin": "sKnflx2C3D73ShadowRoundedBottom",
                "top": "60dp",
                "width": "235px",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegStatus.setDefaultUnit(kony.flex.DP);
            var segStatus = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblUserName": "Redeemed"
                }, {
                    "lblUserName": "Unutilised"
                }],
                "groupCells": false,
                "height": "90%",
                "id": "segStatus",
                "isVisible": true,
                "left": "5dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "segRoundedCornerpx30",
                "rowTemplate": "flxUserList",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": true,
                "showScrollbars": false,
                "top": "20dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxUserList": "flxUserList",
                    "lblUserName": "lblUserName"
                },
                "width": "95.92%",
                "zIndex": 20,
                "appName": "MurahabaLoan"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegStatus.add(segStatus);
            flxGroupCalender.add(CalenderStartDate, CalenderEndDate, flxVoucherStatus, flxSegStatus);
            var flxVoucherDetailSection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50%",
                "id": "flxVoucherDetailSection",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "7%",
                "isModalContainer": false,
                "skin": "sknflxbgF0F0F03opxRounded",
                "top": "48%",
                "width": "85%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxVoucherDetailSection.setDefaultUnit(kony.flex.DP);
            var lblDownloadMessage = new kony.ui.Label({
                "centerX": "50%",
                "height": "50dp",
                "id": "lblDownloadMessage",
                "isVisible": true,
                "skin": "sknlbl2c3d7335pxBold",
                "text": "% records are ready to download",
                "top": "0dp",
                "width": "45%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnDownloadVoucher = new kony.ui.Button({
                "bottom": "10dp",
                "centerX": "50%",
                "height": "50dp",
                "id": "btnDownloadVoucher",
                "isVisible": true,
                "skin": "sknbtn2c3d73Rounded18px",
                "text": "Download Voucher MI Record",
                "width": "30%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnGenerateVoucher = new kony.ui.Button({
                "bottom": "0dp",
                "centerX": "50%",
                "centerY": "50%",
                "height": "50dp",
                "id": "btnGenerateVoucher",
                "isVisible": true,
                "skin": "btn919191GreyBorderWhite",
                "text": "Generate Voucher",
                "width": "30%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxscrollvoucherlist = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "300dp",
                "horizontalScrollIndicator": true,
                "id": "flxscrollvoucherlist",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_HORIZONTAL,
                "skin": "slFSbox",
                "top": "80dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxscrollvoucherlist.setDefaultUnit(kony.flex.DP);
            var segVoucherData = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [
                    [{
                            "lblAmount": "Amount",
                            "lblApplicantName": "Applicant Name",
                            "lblApplicantPhone": "Applicant Phone Number",
                            "lblApplicatntId": "Applicant ID",
                            "lblExpiryDate": "Expiry Date",
                            "lblGenerateDate": "Generation Date",
                            "lblRetailerName": "Retail Partner's name",
                            "lblUserId": "Redeemed by User Id",
                            "lblVoucherNo": "Voucher Number",
                            "lblVoucherStatus": "Voucher Status",
                            "lbldate": "Date & Time"
                        },
                        [{
                            "lblApplicantName": "",
                            "lblApplicantPhone": "",
                            "lblApplicatntId": "",
                            "lblDateTime": "",
                            "lblExpiryDate": "",
                            "lblGenerationDate": "",
                            "lblLoanAmount": "",
                            "lblRetailerName": "",
                            "lblUserID": "",
                            "lblVoucherNumber": "",
                            "lblVoucherStatus": ""
                        }]
                    ]
                ],
                "groupCells": false,
                "height": "300dp",
                "id": "segVoucherData",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxSegVoucherList",
                "sectionHeaderSkin": "sknseghdrwhitebg",
                "sectionHeaderTemplate": "flxVoucherHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": true,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "Copyflx0aa6c3fcb945146": "Copyflx0aa6c3fcb945146",
                    "Copyflx0b0429c32662845": "Copyflx0b0429c32662845",
                    "Copyflx0b32f0b58130443": "Copyflx0b32f0b58130443",
                    "Copyflx0b44e9847ab5b4a": "Copyflx0b44e9847ab5b4a",
                    "Copyflx0d073f3cf227742": "Copyflx0d073f3cf227742",
                    "Copyflx0f094c8b43cea49": "Copyflx0f094c8b43cea49",
                    "Copyflx0f26bb64162554d": "Copyflx0f26bb64162554d",
                    "Copyflx0f522cba27e0f47": "Copyflx0f522cba27e0f47",
                    "Copyflx0h4855b8f989f47": "Copyflx0h4855b8f989f47",
                    "Copyflx0hf84cd2fd1da4b": "Copyflx0hf84cd2fd1da4b",
                    "flx1": "flx1",
                    "flxSegVoucherList": "flxSegVoucherList",
                    "flxVoucherHeader": "flxVoucherHeader",
                    "lblAmount": "lblAmount",
                    "lblApplicantName": "lblApplicantName",
                    "lblApplicantPhone": "lblApplicantPhone",
                    "lblApplicatntId": "lblApplicatntId",
                    "lblDateTime": "lblDateTime",
                    "lblExpiryDate": "lblExpiryDate",
                    "lblGenerateDate": "lblGenerateDate",
                    "lblGenerationDate": "lblGenerationDate",
                    "lblLoanAmount": "lblLoanAmount",
                    "lblRetailerName": "lblRetailerName",
                    "lblUserID": "lblUserID",
                    "lblUserId": "lblUserId",
                    "lblVoucherNo": "lblVoucherNo",
                    "lblVoucherNumber": "lblVoucherNumber",
                    "lblVoucherStatus": "lblVoucherStatus",
                    "lbldate": "lbldate"
                },
                "width": "200%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxscrollvoucherlist.add(segVoucherData);
            flxVoucherDetailSection.add(lblDownloadMessage, btnDownloadVoucher, btnGenerateVoucher, flxscrollvoucherlist);
            var flxConfirmationPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "510px",
                "id": "flxConfirmationPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxBgWhite30PxRadius",
                "top": "0dp",
                "width": "552px",
                "zIndex": 10,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmationPopup.setDefaultUnit(kony.flex.DP);
            var lblRetailPater = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblRetailPater",
                "isVisible": true,
                "skin": "sknlbl20pxCalibriGrey",
                "text": "RETAIL PATNER PORTAL",
                "top": "15%",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "3px",
                "id": "flxLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxRedLine",
                "top": "21%",
                "width": "33px",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxLine.setDefaultUnit(kony.flex.DP);
            flxLine.add();
            var lblConfirmation = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblConfirmation",
                "isVisible": true,
                "skin": "sknlbl2c3d7335pxBold",
                "text": "You have successfully exported 25 records",
                "top": "30%",
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBtn = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxBtn",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "55%",
                "width": "100%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxBtn.setDefaultUnit(kony.flex.DP);
            var flxSep1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "2px",
                "id": "flxSep1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknlbl6A7E9BLine",
                "top": "15%",
                "width": "274px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxSep1.setDefaultUnit(kony.flex.DP);
            flxSep1.add();
            var btnContinue = new kony.ui.Button({
                "centerX": "49.99%",
                "height": "50dp",
                "id": "btnContinue",
                "isVisible": true,
                "left": "0",
                "skin": "sknbtnNoBg2C3D73px24",
                "text": "Continue",
                "top": "35%",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBtn.add(flxSep1, btnContinue);
            flxConfirmationPopup.add(lblRetailPater, flxLine, lblConfirmation, flxBtn);
            var flxSegmentVoucherStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0",
                "clipBounds": false,
                "height": "350px",
                "id": "flxSegmentVoucherStatus",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "67.47%",
                "isModalContainer": false,
                "skin": "sKnflx2C3D73ShadowRoundedBottom",
                "top": "39.50%",
                "width": "250px",
                "zIndex": 10,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegmentVoucherStatus.setDefaultUnit(kony.flex.DP);
            var segVoucherStatus = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }],
                "groupCells": false,
                "height": "95.53%",
                "id": "segVoucherStatus",
                "isVisible": true,
                "left": "8dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "segRoundedCornerpx30",
                "rowTemplate": "flxUserList",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "e4e4e433",
                "separatorRequired": true,
                "showScrollbars": false,
                "top": "11dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxUserList": "flxUserList",
                    "lblUserName": "lblUserName"
                },
                "width": "95.92%",
                "appName": "MurahabaLoan"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegmentVoucherStatus.add(segVoucherStatus);
            flxGenerateVoucher.add(flxTopHeader, flxSearch, flxSegmentSearchList, flxGroupCalender, flxVoucherDetailSection, flxConfirmationPopup, flxSegmentVoucherStatus);
            flxRightPane.add(imgBg, flxGenerateVoucher);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "HeaderComponentPostLogin": {
                    "height": "100px",
                    "zIndex": 3
                },
                "leftpane.flxCreateNewUser": {
                    "layoutType": kony.flex.FREE_FORM
                },
                "leftpane.flxHomePage": {
                    "top": "150px",
                    "layoutType": kony.flex.FREE_FORM
                },
                "leftpane.lblCreateNewUser": {
                    "left": "48dp",
                    "top": ""
                },
                "leftpane.lblHomePage": {
                    "left": "48dp"
                },
                "leftpane": {
                    "height": "924px",
                    "top": "100px",
                    "width": "300px",
                    "zIndex": 3
                }
            }
            this.add(HeaderComponentPostLogin, leftpane, flxRightPane);
        };
        return [{
            "addWidgets": addWidgetsfrmGenerateVoucherMI,
            "enabledForIdleTimeout": false,
            "id": "frmGenerateVoucherMI",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "preShow": function(eventobject) {
                controller.AS_Form_c5331811c77b48e3b9a505562ad4acce(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "MurahabaLoan"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});