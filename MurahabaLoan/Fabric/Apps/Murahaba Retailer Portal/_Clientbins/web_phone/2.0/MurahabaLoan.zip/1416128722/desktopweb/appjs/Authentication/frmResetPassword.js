define("Authentication/frmResetPassword", function() {
    return function(controller) {
        function addWidgetsfrmResetPassword() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknflxscrollbggrey",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "10%",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var HeaderComponent = new com.HeaderComponent({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "HeaderComponent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan",
                "overrides": {
                    "HeaderComponent": {
                        "height": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(HeaderComponent);
            var flxContainerSection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "613px",
                "id": "flxContainerSection",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sKnflxGreyBorder25px",
                "top": "157px",
                "width": "90%",
                "zIndex": 2,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxContainerSection.setDefaultUnit(kony.flex.DP);
            var flxLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "45%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var lblRetailPrtner = new kony.ui.Label({
                "id": "lblRetailPrtner",
                "isVisible": true,
                "left": "80px",
                "skin": "sknlbl18pxCalibriGrey",
                "text": "RETAIL PATNER PORTAL",
                "top": "60px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLoginContenet = new kony.ui.Label({
                "id": "lblLoginContenet",
                "isVisible": true,
                "left": "80px",
                "skin": "sknlbl2c3d7335pxBold",
                "text": "You need to reset your password",
                "top": "90px",
                "width": "500px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPasswordInfo = new kony.ui.Label({
                "id": "lblPasswordInfo",
                "isVisible": true,
                "left": "90px",
                "skin": "sknlbl18px6A7E9B",
                "text": "For Secuirty reason you need to set your new password",
                "top": "145px",
                "width": "400px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "48px",
                "id": "flxLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "80px",
                "isModalContainer": false,
                "skin": "sknflxRedLine",
                "top": "142px",
                "width": "3px",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxLine.setDefaultUnit(kony.flex.DP);
            flxLine.add();
            flxLeft.add(lblRetailPrtner, lblLoginContenet, lblPasswordInfo, flxLine);
            var flxRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "478px",
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "90px",
                "skin": "sknflxGreyBGBorder30PX",
                "top": "60px",
                "width": "530px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxpasswordbox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxpasswordbox",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "88px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40px",
                "width": "354px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxpasswordbox.setDefaultUnit(kony.flex.DP);
            var lblpassword = new kony.ui.Label({
                "id": "lblpassword",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px20",
                "text": "PASSWORD",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtPassword = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtPassword",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Enter your password",
                "secureTextEntry": true,
                "skin": "skntxtboxwhiterounded",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxpasswordbox.add(lblpassword, txtPassword);
            var flxrepeatpassword = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxrepeatpassword",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "88px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30px",
                "width": "354px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxrepeatpassword.setDefaultUnit(kony.flex.DP);
            var lblRepeatPassword = new kony.ui.Label({
                "id": "lblRepeatPassword",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl2c3d73px20",
                "text": "REPEAT PASSWORD",
                "top": "0dp",
                "width": "150px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtRepeatPassword = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtRepeatPassword",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Repeat your password",
                "secureTextEntry": true,
                "skin": "skntxtboxwhiterounded",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxrepeatpassword.add(lblRepeatPassword, txtRepeatPassword);
            var flxpwdrules = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxpwdrules",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "88px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30px",
                "width": "354px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxpwdrules.setDefaultUnit(kony.flex.DP);
            var flxRule1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "22px",
                "id": "flxRule1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxRule1.setDefaultUnit(kony.flex.DP);
            var img1 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "15px",
                "id": "img1",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "tick1x.png",
                "top": "0dp",
                "width": "14px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRule1 = new kony.ui.Label({
                "id": "lblRule1",
                "isVisible": true,
                "left": "25dp",
                "skin": "sknlbl18px6A7E9B",
                "text": "Minimum length of 6 characters",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRule1.add(img1, lblRule1);
            var CopyflxRule0a372fec4ccde4f = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "22px",
                "id": "CopyflxRule0a372fec4ccde4f",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxRule0a372fec4ccde4f.setDefaultUnit(kony.flex.DP);
            var img2 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "15px",
                "id": "img2",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "tick1x.png",
                "top": "0dp",
                "width": "14px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopylblRule0d935f9828ac244 = new kony.ui.Label({
                "id": "CopylblRule0d935f9828ac244",
                "isVisible": true,
                "left": "25dp",
                "skin": "sknlbl18px6A7E9B",
                "text": "Uppercase and lowercase letter (A, z)",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxRule0a372fec4ccde4f.add(img2, CopylblRule0d935f9828ac244);
            var CopyflxRule0h171baf2961347 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "22px",
                "id": "CopyflxRule0h171baf2961347",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxRule0h171baf2961347.setDefaultUnit(kony.flex.DP);
            var img3 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "15px",
                "id": "img3",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "tick1x.png",
                "top": "0dp",
                "width": "14px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopylblRule0ac0c0988d6574f = new kony.ui.Label({
                "id": "CopylblRule0ac0c0988d6574f",
                "isVisible": true,
                "left": "25dp",
                "skin": "sknlbl18px6A7E9B",
                "text": "Numeric character (0-9)",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxRule0h171baf2961347.add(img3, CopylblRule0ac0c0988d6574f);
            var CopyflxRule0j8f344d5272d41 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "75px",
                "id": "CopyflxRule0j8f344d5272d41",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxRule0j8f344d5272d41.setDefaultUnit(kony.flex.DP);
            var img4 = new kony.ui.Image2({
                "height": "15px",
                "id": "img4",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "tick1x.png",
                "top": "5dp",
                "width": "14px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopylblRule0f8fa9dcc6ee543 = new kony.ui.Label({
                "id": "CopylblRule0f8fa9dcc6ee543",
                "isVisible": true,
                "left": "25dp",
                "skin": "sknlbl18px6A7E9B",
                "text": "Special character (any character that is not an uppercase or a lowercase letter or a numeric character — for example, !, %, @, #)",
                "top": "0dp",
                "width": "350px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxRule0j8f344d5272d41.add(img4, CopylblRule0f8fa9dcc6ee543);
            flxpwdrules.add(flxRule1, CopyflxRule0a372fec4ccde4f, CopyflxRule0h171baf2961347, CopyflxRule0j8f344d5272d41);
            var flxAction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxAction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxAction.setDefaultUnit(kony.flex.DP);
            var btnContinue = new kony.ui.Button({
                "bottom": 10,
                "height": "50dp",
                "id": "btnContinue",
                "isVisible": true,
                "right": "70px",
                "skin": "sknbtn2c3d73Rounded18px",
                "text": "Continue    >",
                "top": "0px",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBack = new kony.ui.Button({
                "centerY": "50%",
                "height": "42px",
                "id": "btnBack",
                "isVisible": true,
                "left": "88px",
                "skin": "sknbtnbackimg",
                "top": "0dp",
                "width": "42px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAction.add(btnContinue, btnBack);
            flxRight.add(flxpasswordbox, flxrepeatpassword, flxpwdrules, flxAction);
            flxContainerSection.add(flxLeft, flxRight);
            var imgBackground = new kony.ui.Image2({
                "height": "1128px",
                "id": "imgBackground",
                "isVisible": true,
                "right": "-5%",
                "skin": "slImage",
                "src": "background1x.png",
                "top": "-239px",
                "width": "1156px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMain.add(flxHeader, flxContainerSection, imgBackground);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "HeaderComponent": {
                    "height": "100%"
                }
            }
            this.add(flxMain);
        };
        return [{
            "addWidgets": addWidgetsfrmResetPassword,
            "enabledForIdleTimeout": false,
            "id": "frmResetPassword",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "preShow": function(eventobject) {
                controller.AS_Form_b890041131274468867d11519e3ef7b7(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "MurahabaLoan"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});