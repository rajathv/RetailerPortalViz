define("Dashboard/frmRedeemVoucher", function() {
    return function(controller) {
        function addWidgetsfrmRedeemVoucher() {
            this.setDefaultUnit(kony.flex.DP);
            var HeaderComponentPostLogin = new com.HeaderComponentPostLogin({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100px",
                "id": "HeaderComponentPostLogin",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slnflxbottomGreyBorder",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "MurahabaLoan",
                "overrides": {
                    "HeaderComponentPostLogin": {
                        "height": "100px",
                        "zIndex": 3
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var leftpane = new com.leftpane({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "924px",
                "id": "leftpane",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "100px",
                "width": "300px",
                "zIndex": 3,
                "appName": "MurahabaLoan",
                "overrides": {
                    "flxCreateNewUser": {
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxHomePage": {
                        "top": "150px",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxLine1": {
                        "isVisible": false
                    },
                    "flxLine2": {
                        "isVisible": false
                    },
                    "flxLine6": {
                        "isVisible": true
                    },
                    "lblCreateNewUser": {
                        "isVisible": true,
                        "left": "48dp",
                        "top": "viz.val_cleared"
                    },
                    "lblHomePage": {
                        "left": "48dp"
                    },
                    "leftpane": {
                        "height": "924px",
                        "top": "100px",
                        "width": "300px",
                        "zIndex": 3
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxRightPane = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "924px",
                "id": "flxRightPane",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "300px",
                "isModalContainer": false,
                "skin": "sknflxbggrey",
                "top": "100px",
                "width": "78%",
                "zIndex": 2,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightPane.setDefaultUnit(kony.flex.DP);
            var imgBg = new kony.ui.Image2({
                "height": "100%",
                "id": "imgBg",
                "isVisible": true,
                "right": 0,
                "skin": "slImage",
                "src": "background1x.png",
                "top": "-10%",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxVoucherSearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "855px",
                "id": "flxVoucherSearch",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1064px",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxVoucherSearch.setDefaultUnit(kony.flex.DP);
            var flxTopHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTopHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopHeader.setDefaultUnit(kony.flex.DP);
            var lblRetailPartnerPortal = new kony.ui.Label({
                "id": "lblRetailPartnerPortal",
                "isVisible": true,
                "left": "70px",
                "skin": "sknlblF0ECE9px40",
                "text": "RETAIL PATNER PORTAL",
                "top": "90px",
                "width": "521px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTopHeader.add(lblRetailPartnerPortal);
            var flxSearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "70px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30px",
                "width": "490px",
                "zIndex": 2,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearch.setDefaultUnit(kony.flex.DP);
            var txtSearchVoucher = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtSearchVoucher",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "Please enter Mobile Number or Voucher Code",
                "secureTextEntry": false,
                "skin": "skntxtboxwhiterounded2c3d73border",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "490px",
                "zIndex": 2
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false
            });
            var flxSearchIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "50%",
                "id": "flxSearchIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "10%",
                "skin": "slFbox",
                "top": "0",
                "width": "10%",
                "zIndex": 2,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchIcon.setDefaultUnit(kony.flex.DP);
            var imgSearch = new kony.ui.Image2({
                "height": "100%",
                "id": "imgSearch",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "search1x.png",
                "top": "0dp",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchIcon.add(imgSearch);
            flxSearch.add(txtSearchVoucher, flxSearchIcon);
            var flxSegmentSearchList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "470px",
                "id": "flxSegmentSearchList",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "70px",
                "isModalContainer": false,
                "skin": "sKnflx2C3D73ShadowRoundedBottom",
                "top": "-30px",
                "width": "490px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegmentSearchList.setDefaultUnit(kony.flex.DP);
            var segVouchers = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblUserName": "Label1"
                }, {
                    "lblUserName": "Label2"
                }, {
                    "lblUserName": "Label3"
                }, {
                    "lblUserName": "Label4"
                }, {
                    "lblUserName": "Label5"
                }],
                "groupCells": false,
                "height": "92%",
                "id": "segVouchers",
                "isVisible": true,
                "left": "8dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "segRoundedCornerpx30",
                "rowTemplate": "flxUserList",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "e4e4e433",
                "separatorRequired": true,
                "showScrollbars": false,
                "top": "25dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxUserList": "flxUserList",
                    "lblUserName": "lblUserName"
                },
                "width": "95.92%",
                "appName": "MurahabaLoan"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegmentSearchList.add(segVouchers);
            flxVoucherSearch.add(flxTopHeader, flxSearch, flxSegmentSearchList);
            var flxVoucherDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "855px",
                "id": "flxVoucherDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30px",
                "isModalContainer": false,
                "skin": "sknflxWhiteBGBorderpx30",
                "top": "50dp",
                "width": "92%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxVoucherDetails.setDefaultUnit(kony.flex.DP);
            var flxTopContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxTopContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopContent.setDefaultUnit(kony.flex.DP);
            var lblVoucherDetails = new kony.ui.Label({
                "id": "lblVoucherDetails",
                "isVisible": true,
                "left": "50px",
                "skin": "sknlbl0b3c62d26px25bold",
                "text": "Voucher Detail",
                "top": "100px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVoucherID = new kony.ui.Label({
                "id": "lblVoucherID",
                "isVisible": false,
                "left": "30px",
                "skin": "sknlbl2c3d73px22",
                "text": "ABC1152212334212",
                "top": "90px",
                "width": "80%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40%",
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "10dp",
                "skin": "slFbox",
                "top": "10dp",
                "width": "6%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "height": "100%",
                "id": "imgClose",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "close1x.png",
                "top": "0dp",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnClose = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "100%",
                "id": "btnClose",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknbtntrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClose.add(imgClose, btnClose);
            var flxGenDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "19.55%",
                "id": "flxGenDate",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "120dp",
                "width": "25%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxGenDate.setDefaultUnit(kony.flex.DP);
            var lblGenDate = new kony.ui.Label({
                "id": "lblGenDate",
                "isVisible": true,
                "left": "30px",
                "skin": "sknlbl14px2c3d73",
                "text": "Generation Date:",
                "top": "10px",
                "width": "105px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblGenerateDateValue = new kony.ui.Label({
                "id": "lblGenerateDateValue",
                "isVisible": true,
                "left": "135px",
                "skin": "sknlbl14px2c3d73",
                "text": "10/14/2022",
                "top": "10px",
                "width": "100px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxGenDate.add(lblGenDate, lblGenerateDateValue);
            var flxExpDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "19.55%",
                "id": "flxExpDate",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "253dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "120dp",
                "width": "25%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxExpDate.setDefaultUnit(kony.flex.DP);
            var lblExpDate = new kony.ui.Label({
                "id": "lblExpDate",
                "isVisible": true,
                "left": "10px",
                "skin": "sknlbl14px2c3d73",
                "text": "Expiry Date:",
                "top": "10px",
                "width": "85px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExpiryDateValue = new kony.ui.Label({
                "id": "lblExpiryDateValue",
                "isVisible": true,
                "left": "85px",
                "skin": "sknlbl14px2c3d73",
                "text": "10/14/2022",
                "top": "10px",
                "width": "100px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxExpDate.add(lblExpDate, lblExpiryDateValue);
            flxTopContent.add(lblVoucherDetails, lblVoucherID, flxClose, flxGenDate, flxExpDate);
            var flxVoucherDetailsSection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70.18%",
                "id": "flxVoucherDetailsSection",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "30px",
                "isModalContainer": false,
                "skin": "sknflxGreyBGBorder30PX",
                "top": "22%",
                "width": "94%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxVoucherDetailsSection.setDefaultUnit(kony.flex.DP);
            var flxLine1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "72dp",
                "id": "flxLine1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxLine1.setDefaultUnit(kony.flex.DP);
            var flxApplicantName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxApplicantName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "45%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxApplicantName.setDefaultUnit(kony.flex.DP);
            var lblApplicantName = new kony.ui.Label({
                "id": "lblApplicantName",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px18",
                "text": "APPLICANT  NAME",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtUApplicantName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtUApplicantName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Enter user name",
                "secureTextEntry": false,
                "skin": "skntxtboxE8E8E8rounded",
                "text": "Muhammed",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxApplicantName.add(lblApplicantName, txtUApplicantName);
            var flxPhone = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxPhone",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0px",
                "skin": "slFbox",
                "top": "0px",
                "width": "45%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhone.setDefaultUnit(kony.flex.DP);
            var lblPhone = new kony.ui.Label({
                "id": "lblPhone",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px18",
                "text": "PHONE NUMBER",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtPhone = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtPhone",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Please select role from drop down",
                "secureTextEntry": false,
                "skin": "skntxtboxE8E8E8rounded",
                "text": "+966 50145122214",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxPhone.add(lblPhone, txtPhone);
            flxLine1.add(flxApplicantName, flxPhone);
            var flxLine2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "72dp",
                "id": "flxLine2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxLine2.setDefaultUnit(kony.flex.DP);
            var flxApplicantID = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxApplicantID",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "45%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxApplicantID.setDefaultUnit(kony.flex.DP);
            var lblApplicantID = new kony.ui.Label({
                "id": "lblApplicantID",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px18",
                "text": "Voucher Number",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtVoucherNumber = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtVoucherNumber",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "00000000000",
                "secureTextEntry": false,
                "skin": "skntxtboxE8E8E8rounded",
                "text": "ABC1151514789",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxApplicantID.add(lblApplicantID, txtVoucherNumber);
            var flxApplicantAddress = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxApplicantAddress",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0px",
                "skin": "slFbox",
                "top": "0px",
                "width": "45%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxApplicantAddress.setDefaultUnit(kony.flex.DP);
            var lblApplicantAddress = new kony.ui.Label({
                "id": "lblApplicantAddress",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px18",
                "text": "Voucher Status",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtVoucherStatus = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtVoucherStatus",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Status",
                "secureTextEntry": false,
                "skin": "skntxtboxE8E8E8rounded",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxApplicantAddress.add(lblApplicantAddress, txtVoucherStatus);
            flxLine2.add(flxApplicantID, flxApplicantAddress);
            var flxLine21 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "72dp",
                "id": "flxLine21",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxLine21.setDefaultUnit(kony.flex.DP);
            var CopyflxApplicantID0eb23bb151de44e = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "CopyflxApplicantID0eb23bb151de44e",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "45%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxApplicantID0eb23bb151de44e.setDefaultUnit(kony.flex.DP);
            var CopylblApplicantID0a30f846e542044 = new kony.ui.Label({
                "id": "CopylblApplicantID0a30f846e542044",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px18",
                "text": "Generation Date",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtGenerateDate = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtGenerateDate",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "12/12/2022",
                "secureTextEntry": false,
                "skin": "skntxtboxE8E8E8rounded",
                "text": "12/12/2022",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            CopyflxApplicantID0eb23bb151de44e.add(CopylblApplicantID0a30f846e542044, txtGenerateDate);
            var CopyflxApplicantAddress0bb6bfb90747645 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "CopyflxApplicantAddress0bb6bfb90747645",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0px",
                "skin": "slFbox",
                "top": "0px",
                "width": "45%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxApplicantAddress0bb6bfb90747645.setDefaultUnit(kony.flex.DP);
            var lblExpiryDate = new kony.ui.Label({
                "id": "lblExpiryDate",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px18",
                "text": "Expiry Date",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtExpiryDate = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtExpiryDate",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "22/12/2022",
                "secureTextEntry": false,
                "skin": "skntxtboxE8E8E8rounded",
                "text": "22/12/2022",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            CopyflxApplicantAddress0bb6bfb90747645.add(lblExpiryDate, txtExpiryDate);
            flxLine21.add(CopyflxApplicantID0eb23bb151de44e, CopyflxApplicantAddress0bb6bfb90747645);
            var flxLine3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "72dp",
                "id": "flxLine3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxLine3.setDefaultUnit(kony.flex.DP);
            var flxMerchnatt24CustId = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxMerchnatt24CustId",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "45%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxMerchnatt24CustId.setDefaultUnit(kony.flex.DP);
            var lblMerchnatt24CustId = new kony.ui.Label({
                "id": "lblMerchnatt24CustId",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px18",
                "text": "MERCHANT'S T24 CUSTOMER ID",
                "top": "0dp",
                "width": "250px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtMerchnatt24CustId = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtMerchnatt24CustId",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Enter user ID",
                "secureTextEntry": false,
                "skin": "skntxtboxE8E8E8rounded",
                "text": "Muhib22123",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxMerchnatt24CustId.add(lblMerchnatt24CustId, txtMerchnatt24CustId);
            var flxLoanAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxLoanAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "45%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanAmount.setDefaultUnit(kony.flex.DP);
            var lblLoanAmount = new kony.ui.Label({
                "id": "lblLoanAmount",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px18",
                "text": "LOAN AMOUNT",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtLoanAmount = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtLoanAmount",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "example@mail.com",
                "secureTextEntry": false,
                "skin": "skntxtboxE8E8E8rounded",
                "text": "30,000 SAR",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxLoanAmount.add(lblLoanAmount, txtLoanAmount);
            flxLine3.add(flxMerchnatt24CustId, flxLoanAmount);
            var flxLine4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "72dp",
                "id": "flxLine4",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxLine4.setDefaultUnit(kony.flex.DP);
            var flxEMI = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxEMI",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "45%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxEMI.setDefaultUnit(kony.flex.DP);
            var lblEmi = new kony.ui.Label({
                "id": "lblEmi",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px18",
                "text": "EMI",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtEmi = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtEmi",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Enter user ID",
                "secureTextEntry": false,
                "skin": "skntxtboxE8E8E8rounded",
                "text": "1360 SAR",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxEMI.add(lblEmi, txtEmi);
            var flxTenor = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxTenor",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0px",
                "skin": "slFbox",
                "top": "0px",
                "width": "45%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxTenor.setDefaultUnit(kony.flex.DP);
            var lblTenor = new kony.ui.Label({
                "id": "lblTenor",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px18",
                "text": "TENOR",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtTenor = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtTenor",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "example@mail.com",
                "secureTextEntry": false,
                "skin": "skntxtboxE8E8E8rounded",
                "text": "36 month",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxTenor.add(lblTenor, txtTenor);
            flxLine4.add(flxEMI, flxTenor);
            var flxBtnSec = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "10%",
                "id": "flxBtnSec",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "70dp",
                "width": "100%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxBtnSec.setDefaultUnit(kony.flex.DP);
            var btnSendOtp = new kony.ui.Button({
                "height": "50dp",
                "id": "btnSendOtp",
                "isVisible": false,
                "left": "22.17%",
                "skin": "sknbtn2c3d73Rounded18pxBorder",
                "text": "Send Otp",
                "top": "0dp",
                "width": "200dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnRedeemVoucher = new kony.ui.Button({
                "height": "50dp",
                "id": "btnRedeemVoucher",
                "isVisible": true,
                "left": "39%",
                "skin": "sknbtn2c3d73Rounded18px",
                "text": "Redeem Voucher",
                "top": "0dp",
                "width": "200dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBtnSec.add(btnSendOtp, btnRedeemVoucher);
            flxVoucherDetailsSection.add(flxLine1, flxLine2, flxLine21, flxLine3, flxLine4, flxBtnSec);
            flxVoucherDetails.add(flxTopContent, flxVoucherDetailsSection);
            var flxOTPSection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "613px",
                "id": "flxOTPSection",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sKnflxGreyBorder25px",
                "top": "5%",
                "width": "90%",
                "zIndex": 2,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxOTPSection.setDefaultUnit(kony.flex.DP);
            var flxLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "45%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var lblRetailPrtner = new kony.ui.Label({
                "id": "lblRetailPrtner",
                "isVisible": true,
                "left": "70px",
                "skin": "sknlbl18pxCalibriGrey",
                "text": "RETAIL PATNER PORTAL",
                "top": "60px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLoginContenet = new kony.ui.Label({
                "id": "lblLoginContenet",
                "isVisible": true,
                "left": "70px",
                "skin": "sknlbl2c3d7335pxBold",
                "text": "We have sent a verification code to the voucher holder",
                "top": "90px",
                "width": "350px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPasswordInfo = new kony.ui.Label({
                "id": "lblPasswordInfo",
                "isVisible": true,
                "left": "80px",
                "skin": "sknlbl18px6A7E9B",
                "text": "To verify voucher please enter it below.",
                "top": "170px",
                "width": "320px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxRedline1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "25px",
                "id": "flxRedline1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "70px",
                "isModalContainer": false,
                "skin": "sknflxRedLine",
                "top": "170px",
                "width": "3px",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxRedline1.setDefaultUnit(kony.flex.DP);
            flxRedline1.add();
            flxLeft.add(lblRetailPrtner, lblLoginContenet, lblPasswordInfo, flxRedline1);
            var flxRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "478px",
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "45%",
                "isModalContainer": false,
                "right": "90px",
                "skin": "sknflxGreyBGBorder30PX",
                "top": "10%",
                "width": "50%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxpasswordbox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxpasswordbox",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "88px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "150px",
                "width": "354px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxpasswordbox.setDefaultUnit(kony.flex.DP);
            var flxOTP = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "35dp",
                "id": "flxOTP",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxOTP.setDefaultUnit(kony.flex.DP);
            var txtotp1 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "skntxtboxbottomborder",
                "height": "40dp",
                "id": "txtotp1",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "maxTextLength": 1,
                "secureTextEntry": false,
                "skin": "skntxtboxbottomborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0px",
                "width": "50px",
                "zIndex": 3
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var txtotp2 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "skntxtboxbottomborder",
                "height": "40dp",
                "id": "txtotp2",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "10px",
                "maxTextLength": 1,
                "secureTextEntry": false,
                "skin": "skntxtboxbottomborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0px",
                "width": "50px",
                "zIndex": 3
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var txtotp3 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "skntxtboxbottomborder",
                "height": "40dp",
                "id": "txtotp3",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "10px",
                "maxTextLength": 1,
                "secureTextEntry": false,
                "skin": "skntxtboxbottomborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0px",
                "width": "50px",
                "zIndex": 3
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var txtotp4 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "skntxtboxbottomborder",
                "height": "40dp",
                "id": "txtotp4",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "10px",
                "maxTextLength": 1,
                "secureTextEntry": false,
                "skin": "skntxtboxbottomborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0px",
                "width": "50px",
                "zIndex": 3
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var txtotp5 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "skntxtboxbottomborder",
                "height": "40dp",
                "id": "txtotp5",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "10px",
                "maxTextLength": 1,
                "secureTextEntry": false,
                "skin": "skntxtboxbottomborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0px",
                "width": "50px",
                "zIndex": 3
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var txtotp6 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "skntxtboxbottomborder",
                "height": "40dp",
                "id": "txtotp6",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "10px",
                "maxTextLength": 1,
                "secureTextEntry": false,
                "skin": "skntxtboxbottomborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0px",
                "width": "50px",
                "zIndex": 3
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxOTP.add(txtotp1, txtotp2, txtotp3, txtotp4, txtotp5, txtotp6);
            var lblnewcode = new kony.ui.Label({
                "id": "lblnewcode",
                "isVisible": false,
                "left": "0",
                "skin": "sknlbl18px2D3E71",
                "text": "Send a new code",
                "top": "10dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnReSend = new kony.ui.Button({
                "id": "btnReSend",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknbtnNoBg2C3D73px18",
                "text": "Send a new code",
                "top": "10dp",
                "width": "200dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblotpresend = new kony.ui.Label({
                "id": "lblotpresend",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl18px6A7E9B",
                "text": "02 : 59",
                "top": "5dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxpasswordbox.add(flxOTP, lblnewcode, btnReSend, lblotpresend);
            var flxError = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxError",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "56px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10px",
                "width": "354px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxError.setDefaultUnit(kony.flex.DP);
            var lblError1 = new kony.ui.Label({
                "id": "lblError1",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblFF4D56px13ErrorMsg",
                "text": "Wrong OTP Entered.",
                "top": "0dp",
                "width": "300px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblError2 = new kony.ui.Label({
                "id": "lblError2",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblFF4D56px13ErrorMsg",
                "text": "Please enter correct OTP code",
                "top": "5dp",
                "width": "300px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblError3 = new kony.ui.Label({
                "id": "lblError3",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblFF4D56px13ErrorMsg",
                "text": "Don't receive a code? Send a new one",
                "top": "5dp",
                "width": "300px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxError.add(lblError1, lblError2, lblError3);
            var flxAction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxAction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "35px",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxAction.setDefaultUnit(kony.flex.DP);
            var btnVerify = new kony.ui.Button({
                "bottom": 10,
                "height": "50dp",
                "id": "btnVerify",
                "isVisible": true,
                "right": "70px",
                "skin": "btnBg2C3D73Rounded",
                "text": "Verify    --->",
                "top": "0px",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBack = new kony.ui.Button({
                "centerY": "50%",
                "height": "42px",
                "id": "btnBack",
                "isVisible": true,
                "left": "88px",
                "skin": "sknbtnbackimg",
                "top": "0dp",
                "width": "42px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAction.add(btnVerify, btnBack);
            flxRight.add(flxpasswordbox, flxError, flxAction);
            flxOTPSection.add(flxLeft, flxRight);
            var flxPopupVoucherNotfound = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "510px",
                "id": "flxPopupVoucherNotfound",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxBgWhite30PxRadius",
                "top": "0dp",
                "width": "552px",
                "zIndex": 10,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopupVoucherNotfound.setDefaultUnit(kony.flex.DP);
            var lblRetailPortalHeader = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblRetailPortalHeader",
                "isVisible": true,
                "skin": "sknlbl20pxCalibriGrey",
                "text": "RETAIL PATNER PORTAL",
                "top": "15%",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLinered = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "3px",
                "id": "flxLinered",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxRedLine",
                "top": "21%",
                "width": "33px",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxLinered.setDefaultUnit(kony.flex.DP);
            flxLinered.add();
            var lblError = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblError",
                "isVisible": true,
                "skin": "sknlbl2c3d7335pxBold",
                "text": "Error",
                "top": "30%",
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVoucherNotFound = new kony.ui.Label({
                "centerX": "50.04%",
                "id": "lblVoucherNotFound",
                "isVisible": true,
                "skin": "sknlbl2c3d7335pxBold",
                "text": "Voucher Not Found",
                "top": "40.00%",
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInfoMsg = new kony.ui.Label({
                "centerX": "50.07%",
                "id": "lblInfoMsg",
                "isVisible": true,
                "skin": "sknlbl18px6A7E9B",
                "text": "Please Search with correct Mobile Number or Voucher Code",
                "top": "50.00%",
                "width": "50%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxContinueBtn = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "110dp",
                "id": "flxContinueBtn",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "65%",
                "width": "100%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxContinueBtn.setDefaultUnit(kony.flex.DP);
            var flxSepLine2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "2px",
                "id": "flxSepLine2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknlbl6A7E9BLine",
                "top": "10%",
                "width": "274px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxSepLine2.setDefaultUnit(kony.flex.DP);
            flxSepLine2.add();
            var btnSearchAgain = new kony.ui.Button({
                "centerX": "49.99%",
                "height": "50dp",
                "id": "btnSearchAgain",
                "isVisible": true,
                "left": "0",
                "skin": "sknbtnNoBg2C3D73px24Bold",
                "text": "Search Again",
                "top": "42%",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContinueBtn.add(flxSepLine2, btnSearchAgain);
            flxPopupVoucherNotfound.add(lblRetailPortalHeader, flxLinered, lblError, lblVoucherNotFound, lblInfoMsg, flxContinueBtn);
            var flxAcknowledgementPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "51.73%",
                "centerY": "48.12%",
                "clipBounds": false,
                "height": "510px",
                "id": "flxAcknowledgementPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxBgWhite30PxRadius",
                "top": "0dp",
                "width": "552px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementPopup.setDefaultUnit(kony.flex.DP);
            var lblRetailPater1 = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblRetailPater1",
                "isVisible": true,
                "skin": "sknlbl20pxCalibriGrey",
                "text": "RETAIL PATNER PORTAL",
                "top": "15%",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLineSection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "3px",
                "id": "flxLineSection",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxRedLine",
                "top": "21%",
                "width": "33px",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxLineSection.setDefaultUnit(kony.flex.DP);
            flxLineSection.add();
            var lblAcknowledgeMsg = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblAcknowledgeMsg",
                "isVisible": true,
                "skin": "sknlbl2c3d7335pxBold",
                "text": "Voucher number ABC1152212334212 successfully redeemed",
                "top": "30%",
                "width": "65%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBtn = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxBtn",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "55%",
                "width": "100%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxBtn.setDefaultUnit(kony.flex.DP);
            var flxSep1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "2px",
                "id": "flxSep1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknlbl6A7E9BLine",
                "top": "15%",
                "width": "274px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxSep1.setDefaultUnit(kony.flex.DP);
            flxSep1.add();
            var btnContinue = new kony.ui.Button({
                "centerX": "49.99%",
                "height": "50dp",
                "id": "btnContinue",
                "isVisible": true,
                "left": "0",
                "skin": "sknbtnNoBg2C3D73px24",
                "text": "Continue",
                "top": "35%",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBtn.add(flxSep1, btnContinue);
            flxAcknowledgementPopup.add(lblRetailPater1, flxLineSection, lblAcknowledgeMsg, flxBtn);
            flxRightPane.add(imgBg, flxVoucherSearch, flxVoucherDetails, flxOTPSection, flxPopupVoucherNotfound, flxAcknowledgementPopup);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "HeaderComponentPostLogin": {
                    "height": "100px",
                    "zIndex": 3
                },
                "leftpane.flxCreateNewUser": {
                    "layoutType": kony.flex.FREE_FORM
                },
                "leftpane.flxHomePage": {
                    "top": "150px",
                    "layoutType": kony.flex.FREE_FORM
                },
                "leftpane.lblCreateNewUser": {
                    "left": "48dp",
                    "top": ""
                },
                "leftpane.lblHomePage": {
                    "left": "48dp"
                },
                "leftpane": {
                    "height": "924px",
                    "top": "100px",
                    "width": "300px",
                    "zIndex": 3
                }
            }
            this.add(HeaderComponentPostLogin, leftpane, flxRightPane);
        };
        return [{
            "addWidgets": addWidgetsfrmRedeemVoucher,
            "enabledForIdleTimeout": false,
            "id": "frmRedeemVoucher",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_c3b6bb41838345ed9c158d6c83a53ba1,
            "preShow": function(eventobject) {
                controller.AS_Form_b348acf341d94a81b6628581b329c938(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "MurahabaLoan"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});