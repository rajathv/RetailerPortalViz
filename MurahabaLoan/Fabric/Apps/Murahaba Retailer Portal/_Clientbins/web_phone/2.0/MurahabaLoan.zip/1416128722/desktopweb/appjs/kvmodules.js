define('applicationController',{
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_AppEvents_jb6525bd56bc445f922c6c8831d0ab82: function AS_AppEvents_jb6525bd56bc445f922c6c8831d0ab82(eventobject) {
        var self = this;
        kony.print("Testing JS Load");
        _kony.mvc.initCompositeApp(true);
        var isIOS13 = (/(iPad|iPhone);.*CPU.*OS 13_\d/i).test(navigator.userAgent);
        if (isIOS13) {
            kony.application.setApplicationBehaviors({
                disableForceRepaint: true
            });
        }
        var moduleName = 'ApplicationManager';
        require([moduleName], function(ApplicationManager) {
            applicationManager = ApplicationManager.getApplicationManager();
            document.body.addEventListener('contextmenu', function(e) {
                e.preventDefault();
                alert(kony.i18n.getLocalizedString("i18n.general.rightclickdisabled"));
            });
        });
    },
    appInit: function(params) {
        skinsInit();
        kony.mvc.registry.add("com.HeaderComponent", {
            "viewName": "HeaderComponent",
            "controllerName": "HeaderComponentController"
        });
        kony.application.registerMaster({
            "namespace": "com",
            "classname": "HeaderComponent",
            "name": "com.HeaderComponent"
        });
        kony.mvc.registry.add("com.HeaderComponentPostLogin", {
            "viewName": "HeaderComponentPostLogin",
            "controllerName": "HeaderComponentPostLoginController"
        });
        kony.application.registerMaster({
            "namespace": "com",
            "classname": "HeaderComponentPostLogin",
            "name": "com.HeaderComponentPostLogin"
        });
        kony.mvc.registry.add("com.leftpane", {
            "viewName": "leftpane",
            "controllerName": "leftpaneController"
        });
        kony.application.registerMaster({
            "namespace": "com",
            "classname": "leftpane",
            "name": "com.leftpane"
        });
        kony.mvc.registry.add("flxSampleRowTemplate", {
            "viewName": "flxSampleRowTemplate",
            "controllerName": "flxSampleRowTemplateController"
        });
        kony.mvc.registry.add("flxSectionHeaderTemplate", {
            "viewName": "flxSectionHeaderTemplate",
            "controllerName": "flxSectionHeaderTemplateController"
        });
        kony.mvc.registry.add("flxUserList", {
            "viewName": "flxUserList",
            "controllerName": "flxUserListController"
        });
        kony.mvc.registry.add("flxVoucherHeader", {
            "viewName": "flxVoucherHeader",
            "controllerName": "flxVoucherHeaderController"
        });
        kony.mvc.registry.add("flxSegVoucherList", {
            "viewName": "flxSegVoucherList",
            "controllerName": "flxSegVoucherListController"
        });
        kony.mvc.registry.add("frmLogin", {
            "viewName": "Authentication/frmLogin",
            "controllerName": "Authentication/frmLoginController"
        });
        kony.mvc.registry.add("frmOtpValidation", {
            "viewName": "Authentication/frmOtpValidation",
            "controllerName": "Authentication/frmOtpValidationController"
        });
        kony.mvc.registry.add("frmResetPassword", {
            "viewName": "Authentication/frmResetPassword",
            "controllerName": "Authentication/frmResetPasswordController"
        });
        kony.mvc.registry.add("frmCreateNewUser", {
            "viewName": "Dashboard/frmCreateNewUser",
            "controllerName": "Dashboard/frmCreateNewUserController"
        });
        kony.mvc.registry.add("frmDashBoard", {
            "viewName": "Dashboard/frmDashBoard",
            "controllerName": "Dashboard/frmDashBoardController"
        });
        kony.mvc.registry.add("frmGenerateVoucherMI", {
            "viewName": "Dashboard/frmGenerateVoucherMI",
            "controllerName": "Dashboard/frmGenerateVoucherMIController"
        });
        kony.mvc.registry.add("frmModifyUser", {
            "viewName": "Dashboard/frmModifyUser",
            "controllerName": "Dashboard/frmModifyUserController"
        });
        kony.mvc.registry.add("frmRedeemVoucher", {
            "viewName": "Dashboard/frmRedeemVoucher",
            "controllerName": "Dashboard/frmRedeemVoucherController"
        });
        kony.mvc.registry.add("frmResetUser", {
            "viewName": "Dashboard/frmResetUser",
            "controllerName": "Dashboard/frmResetUserController"
        });
        setAppBehaviors();
    },
    postAppInitCallBack: function(eventObj) {},
    appmenuseq: function() {
        new kony.mvc.Navigation("frmLogin").navigate();
    }
});

define("com/HeaderComponent/userHeaderComponentController", [],function() {
    return {};
});
define("com/HeaderComponent/HeaderComponentControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/HeaderComponent/HeaderComponentController", ["com/HeaderComponent/userHeaderComponentController", "com/HeaderComponent/HeaderComponentControllerActions"], function() {
    var controller = require("com/HeaderComponent/userHeaderComponentController");
    var actions = require("com/HeaderComponent/HeaderComponentControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});

define('com/HeaderComponent/HeaderComponent',[],function() {
    return function(controller) {
        var HeaderComponent = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "isMaster": true,
            "height": "100%",
            "id": "HeaderComponent",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "MurahabaLoan"
        }, controller.args[0], "HeaderComponent"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "HeaderComponent"), extendConfig({}, controller.args[2], "HeaderComponent"));
        HeaderComponent.setDefaultUnit(kony.flex.DP);
        var flxHeader = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "100px",
            "id": "flxHeader",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slnflxbottomGreyBorder",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, controller.args[0], "flxHeader"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxHeader"), extendConfig({}, controller.args[2], "flxHeader"));
        flxHeader.setDefaultUnit(kony.flex.DP);
        var btnSignup = new kony.ui.Button(extendConfig({
            "centerY": "40px",
            "height": "40px",
            "id": "btnSignup",
            "isVisible": true,
            "right": "75px",
            "skin": "sknbtn",
            "text": "Sign Up",
            "width": "256px",
            "zIndex": 1
        }, controller.args[0], "btnSignup"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnSignup"), extendConfig({}, controller.args[2], "btnSignup"));
        var flxLogoContianer = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "100px",
            "centerY": "40px",
            "clipBounds": false,
            "height": "35px",
            "id": "flxLogoContianer",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "120px",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, controller.args[0], "flxLogoContianer"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxLogoContianer"), extendConfig({}, controller.args[2], "flxLogoContianer"));
        flxLogoContianer.setDefaultUnit(kony.flex.DP);
        var Label0cf1016cc307943 = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "25px",
            "id": "Label0cf1016cc307943",
            "isVisible": true,
            "left": "35px",
            "skin": "sknlblheaderblue",
            "text": "mora",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "Label0cf1016cc307943"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "Label0cf1016cc307943"), extendConfig({}, controller.args[2], "Label0cf1016cc307943"));
        var Image0ed0f18d8ce2b4b = new kony.ui.Image2(extendConfig({
            "centerY": "55%",
            "height": "32px",
            "id": "Image0ed0f18d8ce2b4b",
            "isVisible": true,
            "left": "1px",
            "skin": "slImage",
            "src": "logo1x.png",
            "width": "32px",
            "zIndex": 1
        }, controller.args[0], "Image0ed0f18d8ce2b4b"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "Image0ed0f18d8ce2b4b"), extendConfig({}, controller.args[2], "Image0ed0f18d8ce2b4b"));
        flxLogoContianer.add(Label0cf1016cc307943, Image0ed0f18d8ce2b4b);
        flxHeader.add(btnSignup, flxLogoContianer);
        HeaderComponent.add(flxHeader);
        return HeaderComponent;
    }
})
;
define('ServiceResponse',[], function() {
    var ServiceResponse = {
        USER_ATTRIBUTES: ''
    };
    return ServiceResponse;
});

define("com/HeaderComponentPostLogin/userHeaderComponentPostLoginController", ['ServiceResponse'], function(ServiceResponse) {
    return {
        onPreShow: function() {
            this.view.flxActionbar.isVisible = true;
            this.view.flxLogout.isVisible = false;
            this.view.btnSignup.text = ServiceResponse.USER_ATTRIBUTES.username;
            this.view.btnRetailerName.text = ServiceResponse.USER_ATTRIBUTES.username;
            this.setActions();
        },
        setActions: function() {
            var self = this;
            this.view.btnSignup.onClick = function() {
                if (self.view.flxLogout.isVisible) {
                    self.view.flxLogout.isVisible = false;
                } else {
                    self.view.flxLogout.isVisible = true;
                }
            };
            this.view.btnRetailerName.onClick = function() {
                self.view.flxLogout.isVisible = false;
            };
            this.view.btnLogout.onClick = function() {
                self.view.flxLogout.isVisible = false;
                applicationManager.getAuthManager().logout(self.logoutSucess, self.logoutError);
            };
        },
        logoutSucess: function(success) {
            var x = new kony.mvc.Navigation("frmLogin");
            x.navigate();
        },
        logoutError: function(error) {
            var x = new kony.mvc.Navigation("frmLogin");
            x.navigate();
        }
    };
});
define("com/HeaderComponentPostLogin/HeaderComponentPostLoginControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_FlexContainer_f0af6a5c871c4c7d825e43456e6791c1: function AS_FlexContainer_f0af6a5c871c4c7d825e43456e6791c1(eventobject) {
        var self = this;
        this.onPreShow();
    }
});
define("com/HeaderComponentPostLogin/HeaderComponentPostLoginController", ["com/HeaderComponentPostLogin/userHeaderComponentPostLoginController", "com/HeaderComponentPostLogin/HeaderComponentPostLoginControllerActions"], function() {
    var controller = require("com/HeaderComponentPostLogin/userHeaderComponentPostLoginController");
    var actions = require("com/HeaderComponentPostLogin/HeaderComponentPostLoginControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});

define('com/HeaderComponentPostLogin/HeaderComponentPostLogin',[],function() {
    return function(controller) {
        var HeaderComponentPostLogin = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "isMaster": true,
            "height": "100px",
            "id": "HeaderComponentPostLogin",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "preShow": function(eventobject) {
                controller.AS_FlexContainer_f0af6a5c871c4c7d825e43456e6791c1(eventobject);
            },
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "MurahabaLoan"
        }, controller.args[0], "HeaderComponentPostLogin"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "HeaderComponentPostLogin"), extendConfig({}, controller.args[2], "HeaderComponentPostLogin"));
        HeaderComponentPostLogin.setDefaultUnit(kony.flex.DP);
        var flxHeader = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "100px",
            "id": "flxHeader",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slnflxbottomGreyBorder",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, controller.args[0], "flxHeader"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxHeader"), extendConfig({}, controller.args[2], "flxHeader"));
        flxHeader.setDefaultUnit(kony.flex.DP);
        var flxActionbar = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": false,
            "height": "40px",
            "id": "flxActionbar",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "75px",
            "skin": "slFbox",
            "width": "256px",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, controller.args[0], "flxActionbar"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxActionbar"), extendConfig({}, controller.args[2], "flxActionbar"));
        flxActionbar.setDefaultUnit(kony.flex.DP);
        var btnSignup = new kony.ui.Button(extendConfig({
            "height": "40px",
            "id": "btnSignup",
            "isVisible": true,
            "right": "0px",
            "skin": "sknbtn",
            "text": "Retailer Admin Name",
            "top": "0px",
            "width": "256px",
            "zIndex": 2
        }, controller.args[0], "btnSignup"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "displayText": true,
            "padding": [5, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnSignup"), extendConfig({}, controller.args[2], "btnSignup"));
        var imgHamburger = new kony.ui.Image2(extendConfig({
            "centerY": "50%",
            "height": "48dp",
            "id": "imgHamburger",
            "isVisible": true,
            "right": "10px",
            "skin": "slImage",
            "src": "hamburger1x.png",
            "width": "48dp",
            "zIndex": 1
        }, controller.args[0], "imgHamburger"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgHamburger"), extendConfig({}, controller.args[2], "imgHamburger"));
        flxActionbar.add(btnSignup, imgHamburger);
        var flxLogout = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "110px",
            "id": "flxLogout",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "75px",
            "skin": "CopyslFbox0gd41f619d5114e",
            "top": "29dp",
            "width": "256px",
            "zIndex": 2,
            "appName": "MurahabaLoan"
        }, controller.args[0], "flxLogout"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxLogout"), extendConfig({}, controller.args[2], "flxLogout"));
        flxLogout.setDefaultUnit(kony.flex.DP);
        var btnRetailerName = new kony.ui.Button(extendConfig({
            "height": "40px",
            "id": "btnRetailerName",
            "isVisible": true,
            "right": "0px",
            "skin": "sknbtnwhite",
            "text": "Retailer Admin Name",
            "top": "2px",
            "width": "256px",
            "zIndex": 2
        }, controller.args[0], "btnRetailerName"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "displayText": true,
            "padding": [5, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnRetailerName"), extendConfig({}, controller.args[2], "btnRetailerName"));
        var btnLogout = new kony.ui.Button(extendConfig({
            "height": "40px",
            "id": "btnLogout",
            "isVisible": true,
            "right": "0px",
            "skin": "sknbtnwhite",
            "text": "Logout",
            "top": "55px",
            "width": "256px",
            "zIndex": 2
        }, controller.args[0], "btnLogout"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "displayText": true,
            "padding": [5, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnLogout"), extendConfig({}, controller.args[2], "btnLogout"));
        var imghamburgerWhite = new kony.ui.Image2(extendConfig({
            "height": "48dp",
            "id": "imghamburgerWhite",
            "isVisible": true,
            "right": "10px",
            "skin": "slImage",
            "src": "hamburgerwhite.png",
            "top": "0dp",
            "width": "48dp",
            "zIndex": 1
        }, controller.args[0], "imghamburgerWhite"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imghamburgerWhite"), extendConfig({}, controller.args[2], "imghamburgerWhite"));
        flxLogout.add(btnRetailerName, btnLogout, imghamburgerWhite);
        var flxLogoContianer = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "100px",
            "centerY": "50%",
            "clipBounds": false,
            "height": "35px",
            "id": "flxLogoContianer",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "120px",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, controller.args[0], "flxLogoContianer"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxLogoContianer"), extendConfig({}, controller.args[2], "flxLogoContianer"));
        flxLogoContianer.setDefaultUnit(kony.flex.DP);
        var Label0cf1016cc307943 = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "25px",
            "id": "Label0cf1016cc307943",
            "isVisible": true,
            "left": "35px",
            "skin": "sknlblheaderblue",
            "text": "mora",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "Label0cf1016cc307943"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "Label0cf1016cc307943"), extendConfig({}, controller.args[2], "Label0cf1016cc307943"));
        var Image0ed0f18d8ce2b4b = new kony.ui.Image2(extendConfig({
            "centerY": "55%",
            "height": "32px",
            "id": "Image0ed0f18d8ce2b4b",
            "isVisible": true,
            "left": "1px",
            "skin": "slImage",
            "src": "logo1x.png",
            "width": "32px",
            "zIndex": 1
        }, controller.args[0], "Image0ed0f18d8ce2b4b"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "Image0ed0f18d8ce2b4b"), extendConfig({}, controller.args[2], "Image0ed0f18d8ce2b4b"));
        flxLogoContianer.add(Label0cf1016cc307943, Image0ed0f18d8ce2b4b);
        flxHeader.add(flxActionbar, flxLogout, flxLogoContianer);
        HeaderComponentPostLogin.add(flxHeader);
        HeaderComponentPostLogin.compInstData = {}
        return HeaderComponentPostLogin;
    }
})
;
define("com/leftpane/userleftpaneController", ['ServiceResponse'], function(ServiceResponse) {
    return {
        onPreShow: function() {
            var user = ServiceResponse.USER_ATTRIBUTES;
            if ((user.role).toLowerCase() !== "admin") {
                this.view.flxCreateNewUser.isVisible = false;
                this.view.flxModifyUser.isVisible = false;
                this.view.flxResetPassword.isVisible = false;
            } else {
                this.view.flxCreateNewUser.isVisible = true;
                this.view.flxModifyUser.isVisible = true;
                this.view.flxResetPassword.isVisible = true;
            }
        }
    };
});
define("com/leftpane/leftpaneControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_FlexContainer_e586819534ae4fb2828bd54e08f8ebdc: function AS_FlexContainer_e586819534ae4fb2828bd54e08f8ebdc(eventobject, x, y) {
        var self = this;
        var x = new kony.mvc.Navigation("frmCreateNewUser");
        x.navigate();
    },
    AS_FlexContainer_j1f9e4b410e34345973dad7ac8a7fb30: function AS_FlexContainer_j1f9e4b410e34345973dad7ac8a7fb30(eventobject, x, y) {
        var self = this;
        var x = new kony.mvc.Navigation("frmGenerateVoucherMI");
        x.navigate();
    },
    AS_FlexContainer_af53079a402e482d8284b16b4e2197c2: function AS_FlexContainer_af53079a402e482d8284b16b4e2197c2(eventobject) {
        var self = this;
        var x = new kony.mvc.Navigation("frmDashBoard");
        x.navigate();
    },
    AS_FlexContainer_ca2b71ca5219454ca88913e0e6088035: function AS_FlexContainer_ca2b71ca5219454ca88913e0e6088035(eventobject) {
        var self = this;
        var x = new kony.mvc.Navigation("frmModifyUser");
        x.navigate();
    },
    AS_FlexContainer_fbb194283db84aa8945e8a6a7b86ab8d: function AS_FlexContainer_fbb194283db84aa8945e8a6a7b86ab8d(eventobject) {
        var self = this;
        var x = new kony.mvc.Navigation("frmRedeemVoucher");
        x.navigate();
    },
    AS_FlexContainer_b48516bc8f2245c69641c21b3fdc8bbb: function AS_FlexContainer_b48516bc8f2245c69641c21b3fdc8bbb(eventobject, x, y) {
        var self = this;
        var x = new kony.mvc.Navigation("frmResetUser");
        x.navigate();
    },
    AS_FlexContainer_fe6f8e6bfcdb4cd1b438aa29cc6c94a6: function AS_FlexContainer_fe6f8e6bfcdb4cd1b438aa29cc6c94a6(eventobject) {
        var self = this;
        this.onPreShow();
    }
});
define("com/leftpane/leftpaneController", ["com/leftpane/userleftpaneController", "com/leftpane/leftpaneControllerActions"], function() {
    var controller = require("com/leftpane/userleftpaneController");
    var actions = require("com/leftpane/leftpaneControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});

define('com/leftpane/leftpane',[],function() {
    return function(controller) {
        var leftpane = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "isMaster": true,
            "height": "100%",
            "id": "leftpane",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "preShow": function(eventobject) {
                controller.AS_FlexContainer_fe6f8e6bfcdb4cd1b438aa29cc6c94a6(eventobject);
            },
            "skin": "slFbox",
            "top": "0px",
            "width": "300px",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "MurahabaLoan"
        }, controller.args[0], "leftpane"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "leftpane"), extendConfig({}, controller.args[2], "leftpane"));
        leftpane.setDefaultUnit(kony.flex.DP);
        var flxLeftpane = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "100%",
            "id": "flxLeftpane",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknflxcolor2C3D73",
            "top": "0dp",
            "width": "300px",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, controller.args[0], "flxLeftpane"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxLeftpane"), extendConfig({}, controller.args[2], "flxLeftpane"));
        flxLeftpane.setDefaultUnit(kony.flex.DP);
        var flxHomePage = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "50px",
            "id": "flxHomePage",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_af53079a402e482d8284b16b4e2197c2,
            "skin": "slFbox",
            "top": "226px",
            "width": "100%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, controller.args[0], "flxHomePage"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxHomePage"), extendConfig({}, controller.args[2], "flxHomePage"));
        flxHomePage.setDefaultUnit(kony.flex.DP);
        var flxLine1 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "100%",
            "id": "flxLine1",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "36px",
            "isModalContainer": false,
            "skin": "sknflxRedLine",
            "top": "0px",
            "width": "5px",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, controller.args[0], "flxLine1"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxLine1"), extendConfig({}, controller.args[2], "flxLine1"));
        flxLine1.setDefaultUnit(kony.flex.DP);
        flxLine1.add();
        var lblHomePage = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "id": "lblHomePage",
            "isVisible": true,
            "left": "48dp",
            "skin": "sknlblwhite",
            "text": "Home Page",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblHomePage"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblHomePage"), extendConfig({}, controller.args[2], "lblHomePage"));
        flxHomePage.add(flxLine1, lblHomePage);
        var flxCreateNewUser = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "50px",
            "id": "flxCreateNewUser",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onTouchStart": controller.AS_FlexContainer_e586819534ae4fb2828bd54e08f8ebdc,
            "skin": "slFbox",
            "top": "40px",
            "width": "100%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, controller.args[0], "flxCreateNewUser"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxCreateNewUser"), extendConfig({}, controller.args[2], "flxCreateNewUser"));
        flxCreateNewUser.setDefaultUnit(kony.flex.DP);
        var flxLine2 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "100%",
            "id": "flxLine2",
            "isVisible": false,
            "layoutType": kony.flex.FREE_FORM,
            "left": "36px",
            "isModalContainer": false,
            "skin": "sknflxRedLine",
            "top": "0px",
            "width": "5px",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, controller.args[0], "flxLine2"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxLine2"), extendConfig({}, controller.args[2], "flxLine2"));
        flxLine2.setDefaultUnit(kony.flex.DP);
        flxLine2.add();
        var lblCreateNewUser = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "id": "lblCreateNewUser",
            "isVisible": true,
            "left": "48dp",
            "skin": "sknlblwhite",
            "text": "Create new user",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblCreateNewUser"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblCreateNewUser"), extendConfig({}, controller.args[2], "lblCreateNewUser"));
        flxCreateNewUser.add(flxLine2, lblCreateNewUser);
        var flxModifyUser = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "50px",
            "id": "flxModifyUser",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_ca2b71ca5219454ca88913e0e6088035,
            "skin": "slFbox",
            "top": "40px",
            "width": "100%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, controller.args[0], "flxModifyUser"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxModifyUser"), extendConfig({}, controller.args[2], "flxModifyUser"));
        flxModifyUser.setDefaultUnit(kony.flex.DP);
        var flxLine3 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "100%",
            "id": "flxLine3",
            "isVisible": false,
            "layoutType": kony.flex.FREE_FORM,
            "left": "36px",
            "isModalContainer": false,
            "skin": "sknflxRedLine",
            "top": "0px",
            "width": "5px",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, controller.args[0], "flxLine3"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxLine3"), extendConfig({}, controller.args[2], "flxLine3"));
        flxLine3.setDefaultUnit(kony.flex.DP);
        flxLine3.add();
        var lblModifyUser = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "id": "lblModifyUser",
            "isVisible": true,
            "left": "48dp",
            "skin": "sknlblwhite",
            "text": "Modify User",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblModifyUser"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblModifyUser"), extendConfig({}, controller.args[2], "lblModifyUser"));
        flxModifyUser.add(flxLine3, lblModifyUser);
        var flxResetPassword = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "50px",
            "id": "flxResetPassword",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onTouchStart": controller.AS_FlexContainer_b48516bc8f2245c69641c21b3fdc8bbb,
            "skin": "slFbox",
            "top": "40px",
            "width": "100%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, controller.args[0], "flxResetPassword"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxResetPassword"), extendConfig({}, controller.args[2], "flxResetPassword"));
        flxResetPassword.setDefaultUnit(kony.flex.DP);
        var flxLine4 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "100%",
            "id": "flxLine4",
            "isVisible": false,
            "layoutType": kony.flex.FREE_FORM,
            "left": "36px",
            "isModalContainer": false,
            "skin": "sknflxRedLine",
            "top": "0px",
            "width": "5px",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, controller.args[0], "flxLine4"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxLine4"), extendConfig({}, controller.args[2], "flxLine4"));
        flxLine4.setDefaultUnit(kony.flex.DP);
        flxLine4.add();
        var lblResetPassword = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "id": "lblResetPassword",
            "isVisible": true,
            "left": "48dp",
            "skin": "sknlblwhite",
            "text": "Reset User Password",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblResetPassword"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblResetPassword"), extendConfig({}, controller.args[2], "lblResetPassword"));
        flxResetPassword.add(flxLine4, lblResetPassword);
        var flxGenerateVoucher = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "50px",
            "id": "flxGenerateVoucher",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onTouchStart": controller.AS_FlexContainer_j1f9e4b410e34345973dad7ac8a7fb30,
            "skin": "slFbox",
            "top": "40px",
            "width": "100%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, controller.args[0], "flxGenerateVoucher"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxGenerateVoucher"), extendConfig({}, controller.args[2], "flxGenerateVoucher"));
        flxGenerateVoucher.setDefaultUnit(kony.flex.DP);
        var flxLine5 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "100%",
            "id": "flxLine5",
            "isVisible": false,
            "layoutType": kony.flex.FREE_FORM,
            "left": "36px",
            "isModalContainer": false,
            "skin": "sknflxRedLine",
            "top": "0px",
            "width": "5px",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, controller.args[0], "flxLine5"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxLine5"), extendConfig({}, controller.args[2], "flxLine5"));
        flxLine5.setDefaultUnit(kony.flex.DP);
        flxLine5.add();
        var lblVoucher = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "id": "lblVoucher",
            "isVisible": true,
            "left": "48dp",
            "skin": "sknlblwhite",
            "text": "Generate Voucher MI",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblVoucher"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblVoucher"), extendConfig({}, controller.args[2], "lblVoucher"));
        flxGenerateVoucher.add(flxLine5, lblVoucher);
        var flxReedemVoucher = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "50px",
            "id": "flxReedemVoucher",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_fbb194283db84aa8945e8a6a7b86ab8d,
            "skin": "slFbox",
            "top": "40px",
            "width": "100%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, controller.args[0], "flxReedemVoucher"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxReedemVoucher"), extendConfig({}, controller.args[2], "flxReedemVoucher"));
        flxReedemVoucher.setDefaultUnit(kony.flex.DP);
        var flxLine6 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "100%",
            "id": "flxLine6",
            "isVisible": false,
            "layoutType": kony.flex.FREE_FORM,
            "left": "36px",
            "isModalContainer": false,
            "skin": "sknflxRedLine",
            "top": "0px",
            "width": "5px",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, controller.args[0], "flxLine6"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxLine6"), extendConfig({}, controller.args[2], "flxLine6"));
        flxLine6.setDefaultUnit(kony.flex.DP);
        flxLine6.add();
        var lblReedemVoucher = new kony.ui.Label(extendConfig({
            "centerY": "50%",
            "id": "lblReedemVoucher",
            "isVisible": true,
            "left": "48dp",
            "skin": "sknlblwhite",
            "text": "Reedem Voucher",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblReedemVoucher"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblReedemVoucher"), extendConfig({}, controller.args[2], "lblReedemVoucher"));
        flxReedemVoucher.add(flxLine6, lblReedemVoucher);
        flxLeftpane.add(flxHomePage, flxCreateNewUser, flxModifyUser, flxResetPassword, flxGenerateVoucher, flxReedemVoucher);
        leftpane.add(flxLeftpane);
        leftpane.compInstData = {}
        return leftpane;
    }
})
;
define("flxSampleRowTemplate", [],function() {
    return function(controller) {
        var flxSampleRowTemplate = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "75dp",
            "id": "flxSampleRowTemplate",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknSampleRowTemplate",
            "width": "100%",
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        flxSampleRowTemplate.setDefaultUnit(kony.flex.DP);
        var lblHeading = new kony.ui.Label({
            "id": "lblHeading",
            "isVisible": true,
            "left": "4%",
            "maxWidth": "50%",
            "skin": "sknLblRowHeading",
            "text": "Heading",
            "textStyle": {},
            "top": "8.00%",
            "width": "45%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblDescription = new kony.ui.Label({
            "bottom": "10%",
            "id": "lblDescription",
            "isVisible": true,
            "left": "4%",
            "maxNumberOfLines": 3,
            "maxWidth": "70%",
            "skin": "sknLblDescription",
            "text": "Sub-Heading",
            "textStyle": {},
            "textTruncatePosition": constants.TEXT_TRUNCATE_NONE,
            "top": "42%",
            "width": "70%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblTime = new kony.ui.Label({
            "id": "lblTime",
            "isVisible": true,
            "right": "9%",
            "skin": "sknLblTimeStamp",
            "text": "Timestamp",
            "textStyle": {},
            "top": "10%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblStrip = new kony.ui.Label({
            "height": "100%",
            "id": "lblStrip",
            "isVisible": true,
            "left": "0dp",
            "maxWidth": "1%",
            "skin": "sknLblStrip",
            "textStyle": {},
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxSampleRowTemplate.add(lblHeading, lblDescription, lblTime, lblStrip);
        return flxSampleRowTemplate;
    }
})
;
define("flxSectionHeaderTemplate", [],function() {
    return function(controller) {
        var flxSectionHeaderTemplate = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "45dp",
            "id": "flxSectionHeaderTemplate",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknSampleSectionHeaderTemplate",
            "width": "100%",
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        flxSectionHeaderTemplate.setDefaultUnit(kony.flex.DP);
        var lblHeading = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblHeading",
            "isVisible": true,
            "left": "4%",
            "maxWidth": "50%",
            "skin": "sknSectionHeaderLabelSkin",
            "text": "Heading",
            "textStyle": {},
            "width": "75%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxSectionHeaderTemplate.add(lblHeading);
        return flxSectionHeaderTemplate;
    }
})
;
define("flxUserList", [],function() {
    return function(controller) {
        var flxUserList = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "60dp",
            "id": "flxUserList",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "breakpoints": [640, 1024, 1366],
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        flxUserList.setDefaultUnit(kony.flex.DP);
        var lblUserName = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblUserName",
            "isVisible": true,
            "left": "20px",
            "skin": "sknlbl2c3d73px25",
            "text": "Label",
            "width": kony.flex.USE_PREFFERED_SIZE
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxUserList.add(lblUserName);
        return flxUserList;
    }
})
;
define("flxVoucherHeader", [],function() {
    return function(controller) {
        var flxVoucherHeader = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "flxVoucherHeader",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "breakpoints": [640, 1024, 1366],
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        flxVoucherHeader.setDefaultUnit(kony.flex.DP);
        var flx1 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "flx1",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "1dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "1dp",
            "width": "8%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        flx1.setDefaultUnit(kony.flex.DP);
        var lblApplicantName = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblApplicantName",
            "isVisible": true,
            "skin": "sknlblblack16PxBold",
            "text": "Applicant Name",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flx1.add(lblApplicantName);
        var Copyflx0h4855b8f989f47 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "Copyflx0h4855b8f989f47",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "1dp",
            "width": "7%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        Copyflx0h4855b8f989f47.setDefaultUnit(kony.flex.DP);
        var lblApplicatntId = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblApplicatntId",
            "isVisible": true,
            "skin": "sknlblblack16PxBold",
            "text": "Applicant ID",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Copyflx0h4855b8f989f47.add(lblApplicatntId);
        var Copyflx0b32f0b58130443 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "Copyflx0b32f0b58130443",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "1dp",
            "width": "12%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        Copyflx0b32f0b58130443.setDefaultUnit(kony.flex.DP);
        var lblApplicantPhone = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblApplicantPhone",
            "isVisible": true,
            "skin": "sknlblblack16PxBold",
            "text": "Applicant Phone Number",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Copyflx0b32f0b58130443.add(lblApplicantPhone);
        var Copyflx0f094c8b43cea49 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "Copyflx0f094c8b43cea49",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "1dp",
            "width": "5%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        Copyflx0f094c8b43cea49.setDefaultUnit(kony.flex.DP);
        var lblAmount = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblAmount",
            "isVisible": true,
            "skin": "sknlblblack16PxBold",
            "text": "Amount",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Copyflx0f094c8b43cea49.add(lblAmount);
        var Copyflx0b44e9847ab5b4a = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "Copyflx0b44e9847ab5b4a",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "1dp",
            "width": "12%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        Copyflx0b44e9847ab5b4a.setDefaultUnit(kony.flex.DP);
        var lblVoucherNo = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblVoucherNo",
            "isVisible": true,
            "skin": "sknlblblack16PxBold",
            "text": "Voucher Number",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Copyflx0b44e9847ab5b4a.add(lblVoucherNo);
        var Copyflx0f522cba27e0f47 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "Copyflx0f522cba27e0f47",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "1dp",
            "width": "7.25%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        Copyflx0f522cba27e0f47.setDefaultUnit(kony.flex.DP);
        var lblVoucherStatus = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblVoucherStatus",
            "isVisible": true,
            "skin": "sknlblblack16PxBold",
            "text": "Voucher Status",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Copyflx0f522cba27e0f47.add(lblVoucherStatus);
        var Copyflx0d073f3cf227742 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "Copyflx0d073f3cf227742",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "1dp",
            "width": "8%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        Copyflx0d073f3cf227742.setDefaultUnit(kony.flex.DP);
        var lblGenerateDate = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblGenerateDate",
            "isVisible": true,
            "skin": "sknlblblack16PxBold",
            "text": "Generation Date",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Copyflx0d073f3cf227742.add(lblGenerateDate);
        var Copyflx0b0429c32662845 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "Copyflx0b0429c32662845",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "1dp",
            "width": "8%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        Copyflx0b0429c32662845.setDefaultUnit(kony.flex.DP);
        var lblExpiryDate = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblExpiryDate",
            "isVisible": true,
            "skin": "sknlblblack16PxBold",
            "text": "Expiry Date",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Copyflx0b0429c32662845.add(lblExpiryDate);
        var Copyflx0hf84cd2fd1da4b = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "Copyflx0hf84cd2fd1da4b",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "1dp",
            "width": "11%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        Copyflx0hf84cd2fd1da4b.setDefaultUnit(kony.flex.DP);
        var lblRetailerName = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblRetailerName",
            "isVisible": true,
            "skin": "sknlblblack16PxBold",
            "text": "Retail Partner's name",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Copyflx0hf84cd2fd1da4b.add(lblRetailerName);
        var Copyflx0aa6c3fcb945146 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "Copyflx0aa6c3fcb945146",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "1dp",
            "width": "13%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        Copyflx0aa6c3fcb945146.setDefaultUnit(kony.flex.DP);
        var lblUserId = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblUserId",
            "isVisible": true,
            "skin": "sknlblblack16PxBold",
            "text": "Redeemed by User Id",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Copyflx0aa6c3fcb945146.add(lblUserId);
        var Copyflx0f26bb64162554d = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "Copyflx0f26bb64162554d",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "1dp",
            "width": "10%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        Copyflx0f26bb64162554d.setDefaultUnit(kony.flex.DP);
        var lbldate = new kony.ui.Label({
            "centerX": "50%",
            "id": "lbldate",
            "isVisible": true,
            "skin": "sknlblblack16PxBold",
            "text": "Date & Time",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Copyflx0f26bb64162554d.add(lbldate);
        flxVoucherHeader.add(flx1, Copyflx0h4855b8f989f47, Copyflx0b32f0b58130443, Copyflx0f094c8b43cea49, Copyflx0b44e9847ab5b4a, Copyflx0f522cba27e0f47, Copyflx0d073f3cf227742, Copyflx0b0429c32662845, Copyflx0hf84cd2fd1da4b, Copyflx0aa6c3fcb945146, Copyflx0f26bb64162554d);
        return flxVoucherHeader;
    }
})
;
define("flxSegVoucherList", [],function() {
    return function(controller) {
        var flxSegVoucherList = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "flxSegVoucherList",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "breakpoints": [640, 1024, 1366],
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        flxSegVoucherList.setDefaultUnit(kony.flex.DP);
        var flx1 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "flx1",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "1dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "0dp",
            "width": "8%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        flx1.setDefaultUnit(kony.flex.DP);
        var lblApplicantName = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblApplicantName",
            "isVisible": true,
            "skin": "sknlblblack16px",
            "text": "Muhaib",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flx1.add(lblApplicantName);
        var Copyflx0h4855b8f989f47 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "Copyflx0h4855b8f989f47",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "0dp",
            "width": "7%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        Copyflx0h4855b8f989f47.setDefaultUnit(kony.flex.DP);
        var lblApplicatntId = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblApplicatntId",
            "isVisible": true,
            "skin": "sknlblblack16px",
            "text": "123456",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Copyflx0h4855b8f989f47.add(lblApplicatntId);
        var Copyflx0b32f0b58130443 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "Copyflx0b32f0b58130443",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "0dp",
            "width": "12%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        Copyflx0b32f0b58130443.setDefaultUnit(kony.flex.DP);
        var lblApplicantPhone = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblApplicantPhone",
            "isVisible": true,
            "skin": "sknlblblack16px",
            "text": "+966 501451224455",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Copyflx0b32f0b58130443.add(lblApplicantPhone);
        var Copyflx0f094c8b43cea49 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "Copyflx0f094c8b43cea49",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "0dp",
            "width": "5%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        Copyflx0f094c8b43cea49.setDefaultUnit(kony.flex.DP);
        var lblLoanAmount = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblLoanAmount",
            "isVisible": true,
            "skin": "sknlblblack16px",
            "text": "20000",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Copyflx0f094c8b43cea49.add(lblLoanAmount);
        var Copyflx0b44e9847ab5b4a = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "Copyflx0b44e9847ab5b4a",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "0dp",
            "width": "12%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        Copyflx0b44e9847ab5b4a.setDefaultUnit(kony.flex.DP);
        var lblVoucherNumber = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblVoucherNumber",
            "isVisible": true,
            "skin": "sknlblblack16px",
            "text": "MORA-456-ADSF",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Copyflx0b44e9847ab5b4a.add(lblVoucherNumber);
        var Copyflx0f522cba27e0f47 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "Copyflx0f522cba27e0f47",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "0dp",
            "width": "7.25%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        Copyflx0f522cba27e0f47.setDefaultUnit(kony.flex.DP);
        var lblVoucherStatus = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblVoucherStatus",
            "isVisible": true,
            "skin": "sknlblblack16px",
            "text": "Redeemed",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Copyflx0f522cba27e0f47.add(lblVoucherStatus);
        var Copyflx0d073f3cf227742 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "Copyflx0d073f3cf227742",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "0dp",
            "width": "8%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        Copyflx0d073f3cf227742.setDefaultUnit(kony.flex.DP);
        var lblGenerationDate = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblGenerationDate",
            "isVisible": true,
            "skin": "sknlblblack16px",
            "text": "11/11/2022",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Copyflx0d073f3cf227742.add(lblGenerationDate);
        var Copyflx0b0429c32662845 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "Copyflx0b0429c32662845",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "0dp",
            "width": "8%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        Copyflx0b0429c32662845.setDefaultUnit(kony.flex.DP);
        var lblExpiryDate = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblExpiryDate",
            "isVisible": true,
            "skin": "sknlblblack16px",
            "text": "21/11/2022",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Copyflx0b0429c32662845.add(lblExpiryDate);
        var Copyflx0hf84cd2fd1da4b = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "Copyflx0hf84cd2fd1da4b",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "0dp",
            "width": "11%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        Copyflx0hf84cd2fd1da4b.setDefaultUnit(kony.flex.DP);
        var lblRetailerName = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblRetailerName",
            "isVisible": true,
            "skin": "sknlblblack16px",
            "text": "Samsung",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Copyflx0hf84cd2fd1da4b.add(lblRetailerName);
        var Copyflx0aa6c3fcb945146 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "Copyflx0aa6c3fcb945146",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "0dp",
            "width": "13%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        Copyflx0aa6c3fcb945146.setDefaultUnit(kony.flex.DP);
        var lblUserID = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblUserID",
            "isVisible": true,
            "skin": "sknlblblack16px",
            "text": "TAL 8009",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Copyflx0aa6c3fcb945146.add(lblUserID);
        var Copyflx0f26bb64162554d = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "Copyflx0f26bb64162554d",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknflxblackborder",
            "top": "0dp",
            "width": "10%",
            "zIndex": 1,
            "appName": "MurahabaLoan"
        }, {
            "paddingInPixel": false
        }, {});
        Copyflx0f26bb64162554d.setDefaultUnit(kony.flex.DP);
        var lblDateTime = new kony.ui.Label({
            "centerX": "50%",
            "id": "lblDateTime",
            "isVisible": true,
            "skin": "sknlblblack16px",
            "text": "11/11/2022",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        Copyflx0f26bb64162554d.add(lblDateTime);
        flxSegVoucherList.add(flx1, Copyflx0h4855b8f989f47, Copyflx0b32f0b58130443, Copyflx0f094c8b43cea49, Copyflx0b44e9847ab5b4a, Copyflx0f522cba27e0f47, Copyflx0d073f3cf227742, Copyflx0b0429c32662845, Copyflx0hf84cd2fd1da4b, Copyflx0aa6c3fcb945146, Copyflx0f26bb64162554d);
        return flxSegVoucherList;
    }
})
;
define("userflxSampleRowTemplateController", {
    //Type your controller code here 
});
define("flxSampleRowTemplateControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxSampleRowTemplateController", ["userflxSampleRowTemplateController", "flxSampleRowTemplateControllerActions"], function() {
    var controller = require("userflxSampleRowTemplateController");
    var controllerActions = ["flxSampleRowTemplateControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxSectionHeaderTemplateController", {
    //Type your controller code here 
});
define("flxSectionHeaderTemplateControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxSectionHeaderTemplateController", ["userflxSectionHeaderTemplateController", "flxSectionHeaderTemplateControllerActions"], function() {
    var controller = require("userflxSectionHeaderTemplateController");
    var controllerActions = ["flxSectionHeaderTemplateControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxUserListController", {
    //Type your controller code here 
});
define("flxUserListControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxUserListController", ["userflxUserListController", "flxUserListControllerActions"], function() {
    var controller = require("userflxUserListController");
    var controllerActions = ["flxUserListControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxVoucherHeaderController", {
    //Type your controller code here 
});
define("flxVoucherHeaderControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxVoucherHeaderController", ["userflxVoucherHeaderController", "flxVoucherHeaderControllerActions"], function() {
    var controller = require("userflxVoucherHeaderController");
    var controllerActions = ["flxVoucherHeaderControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxSegVoucherListController", {
    //Type your controller code here 
});
define("flxSegVoucherListControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxSegVoucherListController", ["userflxSegVoucherListController", "flxSegVoucherListControllerActions"], function() {
    var controller = require("userflxSegVoucherListController");
    var controllerActions = ["flxSegVoucherListControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("navigation/NavigationModel", { 
    "Application": {},
    "Forms" : {},
    "UIModules" : {}
});

define("navigation/NavigationController", {
    //Add your navigation controller code here.
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('RepoManagerConfig',[], function() {
    var repoMapping = {
        Retailer: {
            model: "RetailerCustomer/Retailer/Model",
            config: "RetailerCustomer/Retailer/MF_Config",
            repository: "RetailerCustomer/Retailer/Repository",
        },
        voucher: {
            model: "VoucherObject/voucher/Model",
            config: "VoucherObject/voucher/MF_Config",
            repository: "VoucherObject/voucher/Repository",
        },
    };
    return repoMapping;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('RetailerCustomer/Retailer/MF_Config',[], function() {
    var mappings = {
        "userid": "userid",
        "password": "password",
        "temppassword": "temppassword",
        "resetpassword": "resetpassword",
        "status": "status",
        "retailerid": "retailerid",
        "retailername": "retailername",
        "role": "role",
        "phoneno": "phoneno",
        "emailid": "emailid",
        "username": "username",
        "securityKey": "securityKey",
        "Otp": "Otp",
        "dbpErrCode": "dbpErrCode",
        "dbpErrMsg": "dbpErrMsg",
        "isOtpVerified": "isOtpVerified",
    };
    Object.freeze(mappings);
    var typings = {
        "userid": "string",
        "password": "string",
        "temppassword": "string",
        "resetpassword": "string",
        "status": "string",
        "retailerid": "string",
        "retailername": "string",
        "role": "string",
        "phoneno": "string",
        "emailid": "string",
        "username": "string",
        "securityKey": "string",
        "Otp": "string",
        "dbpErrCode": "string",
        "dbpErrMsg": "string",
        "isOtpVerified": "string",
    }
    Object.freeze(typings);
    var primaryKeys = ["userid", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "RetailerCustomer",
        tableName: "Retailer"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('RetailerCustomer/Retailer/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Retailer",
        "objectService": "RetailerCustomer"
    };
    var setterFunctions = {
        userid: function(val, state) {
            context["field"] = "userid";
            context["metadata"] = (objectMetadata ? objectMetadata["userid"] : null);
            state['userid'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        password: function(val, state) {
            context["field"] = "password";
            context["metadata"] = (objectMetadata ? objectMetadata["password"] : null);
            state['password'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        temppassword: function(val, state) {
            context["field"] = "temppassword";
            context["metadata"] = (objectMetadata ? objectMetadata["temppassword"] : null);
            state['temppassword'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        resetpassword: function(val, state) {
            context["field"] = "resetpassword";
            context["metadata"] = (objectMetadata ? objectMetadata["resetpassword"] : null);
            state['resetpassword'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        status: function(val, state) {
            context["field"] = "status";
            context["metadata"] = (objectMetadata ? objectMetadata["status"] : null);
            state['status'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        retailerid: function(val, state) {
            context["field"] = "retailerid";
            context["metadata"] = (objectMetadata ? objectMetadata["retailerid"] : null);
            state['retailerid'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        retailername: function(val, state) {
            context["field"] = "retailername";
            context["metadata"] = (objectMetadata ? objectMetadata["retailername"] : null);
            state['retailername'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        role: function(val, state) {
            context["field"] = "role";
            context["metadata"] = (objectMetadata ? objectMetadata["role"] : null);
            state['role'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        phoneno: function(val, state) {
            context["field"] = "phoneno";
            context["metadata"] = (objectMetadata ? objectMetadata["phoneno"] : null);
            state['phoneno'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        emailid: function(val, state) {
            context["field"] = "emailid";
            context["metadata"] = (objectMetadata ? objectMetadata["emailid"] : null);
            state['emailid'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        username: function(val, state) {
            context["field"] = "username";
            context["metadata"] = (objectMetadata ? objectMetadata["username"] : null);
            state['username'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        securityKey: function(val, state) {
            context["field"] = "securityKey";
            context["metadata"] = (objectMetadata ? objectMetadata["securityKey"] : null);
            state['securityKey'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Otp: function(val, state) {
            context["field"] = "Otp";
            context["metadata"] = (objectMetadata ? objectMetadata["Otp"] : null);
            state['Otp'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        dbpErrCode: function(val, state) {
            context["field"] = "dbpErrCode";
            context["metadata"] = (objectMetadata ? objectMetadata["dbpErrCode"] : null);
            state['dbpErrCode'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        dbpErrMsg: function(val, state) {
            context["field"] = "dbpErrMsg";
            context["metadata"] = (objectMetadata ? objectMetadata["dbpErrMsg"] : null);
            state['dbpErrMsg'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        isOtpVerified: function(val, state) {
            context["field"] = "isOtpVerified";
            context["metadata"] = (objectMetadata ? objectMetadata["isOtpVerified"] : null);
            state['isOtpVerified'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Retailer(defaultValues) {
        var privateState = {};
        context["field"] = "userid";
        context["metadata"] = (objectMetadata ? objectMetadata["userid"] : null);
        privateState.userid = defaultValues ? (defaultValues["userid"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["userid"], context) : null) : null;
        context["field"] = "password";
        context["metadata"] = (objectMetadata ? objectMetadata["password"] : null);
        privateState.password = defaultValues ? (defaultValues["password"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["password"], context) : null) : null;
        context["field"] = "temppassword";
        context["metadata"] = (objectMetadata ? objectMetadata["temppassword"] : null);
        privateState.temppassword = defaultValues ? (defaultValues["temppassword"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["temppassword"], context) : null) : null;
        context["field"] = "resetpassword";
        context["metadata"] = (objectMetadata ? objectMetadata["resetpassword"] : null);
        privateState.resetpassword = defaultValues ? (defaultValues["resetpassword"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["resetpassword"], context) : null) : null;
        context["field"] = "status";
        context["metadata"] = (objectMetadata ? objectMetadata["status"] : null);
        privateState.status = defaultValues ? (defaultValues["status"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["status"], context) : null) : null;
        context["field"] = "retailerid";
        context["metadata"] = (objectMetadata ? objectMetadata["retailerid"] : null);
        privateState.retailerid = defaultValues ? (defaultValues["retailerid"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["retailerid"], context) : null) : null;
        context["field"] = "retailername";
        context["metadata"] = (objectMetadata ? objectMetadata["retailername"] : null);
        privateState.retailername = defaultValues ? (defaultValues["retailername"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["retailername"], context) : null) : null;
        context["field"] = "role";
        context["metadata"] = (objectMetadata ? objectMetadata["role"] : null);
        privateState.role = defaultValues ? (defaultValues["role"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["role"], context) : null) : null;
        context["field"] = "phoneno";
        context["metadata"] = (objectMetadata ? objectMetadata["phoneno"] : null);
        privateState.phoneno = defaultValues ? (defaultValues["phoneno"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["phoneno"], context) : null) : null;
        context["field"] = "emailid";
        context["metadata"] = (objectMetadata ? objectMetadata["emailid"] : null);
        privateState.emailid = defaultValues ? (defaultValues["emailid"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["emailid"], context) : null) : null;
        context["field"] = "username";
        context["metadata"] = (objectMetadata ? objectMetadata["username"] : null);
        privateState.username = defaultValues ? (defaultValues["username"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["username"], context) : null) : null;
        context["field"] = "securityKey";
        context["metadata"] = (objectMetadata ? objectMetadata["securityKey"] : null);
        privateState.securityKey = defaultValues ? (defaultValues["securityKey"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["securityKey"], context) : null) : null;
        context["field"] = "Otp";
        context["metadata"] = (objectMetadata ? objectMetadata["Otp"] : null);
        privateState.Otp = defaultValues ? (defaultValues["Otp"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Otp"], context) : null) : null;
        context["field"] = "dbpErrCode";
        context["metadata"] = (objectMetadata ? objectMetadata["dbpErrCode"] : null);
        privateState.dbpErrCode = defaultValues ? (defaultValues["dbpErrCode"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["dbpErrCode"], context) : null) : null;
        context["field"] = "dbpErrMsg";
        context["metadata"] = (objectMetadata ? objectMetadata["dbpErrMsg"] : null);
        privateState.dbpErrMsg = defaultValues ? (defaultValues["dbpErrMsg"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["dbpErrMsg"], context) : null) : null;
        context["field"] = "isOtpVerified";
        context["metadata"] = (objectMetadata ? objectMetadata["isOtpVerified"] : null);
        privateState.isOtpVerified = defaultValues ? (defaultValues["isOtpVerified"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["isOtpVerified"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "userid": {
                get: function() {
                    context["field"] = "userid";
                    context["metadata"] = (objectMetadata ? objectMetadata["userid"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.userid, context);
                },
                set: function(val) {
                    setterFunctions['userid'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "password": {
                get: function() {
                    context["field"] = "password";
                    context["metadata"] = (objectMetadata ? objectMetadata["password"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.password, context);
                },
                set: function(val) {
                    setterFunctions['password'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "temppassword": {
                get: function() {
                    context["field"] = "temppassword";
                    context["metadata"] = (objectMetadata ? objectMetadata["temppassword"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.temppassword, context);
                },
                set: function(val) {
                    setterFunctions['temppassword'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "resetpassword": {
                get: function() {
                    context["field"] = "resetpassword";
                    context["metadata"] = (objectMetadata ? objectMetadata["resetpassword"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.resetpassword, context);
                },
                set: function(val) {
                    setterFunctions['resetpassword'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "status": {
                get: function() {
                    context["field"] = "status";
                    context["metadata"] = (objectMetadata ? objectMetadata["status"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.status, context);
                },
                set: function(val) {
                    setterFunctions['status'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "retailerid": {
                get: function() {
                    context["field"] = "retailerid";
                    context["metadata"] = (objectMetadata ? objectMetadata["retailerid"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.retailerid, context);
                },
                set: function(val) {
                    setterFunctions['retailerid'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "retailername": {
                get: function() {
                    context["field"] = "retailername";
                    context["metadata"] = (objectMetadata ? objectMetadata["retailername"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.retailername, context);
                },
                set: function(val) {
                    setterFunctions['retailername'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "role": {
                get: function() {
                    context["field"] = "role";
                    context["metadata"] = (objectMetadata ? objectMetadata["role"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.role, context);
                },
                set: function(val) {
                    setterFunctions['role'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "phoneno": {
                get: function() {
                    context["field"] = "phoneno";
                    context["metadata"] = (objectMetadata ? objectMetadata["phoneno"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.phoneno, context);
                },
                set: function(val) {
                    setterFunctions['phoneno'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "emailid": {
                get: function() {
                    context["field"] = "emailid";
                    context["metadata"] = (objectMetadata ? objectMetadata["emailid"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.emailid, context);
                },
                set: function(val) {
                    setterFunctions['emailid'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "username": {
                get: function() {
                    context["field"] = "username";
                    context["metadata"] = (objectMetadata ? objectMetadata["username"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.username, context);
                },
                set: function(val) {
                    setterFunctions['username'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "securityKey": {
                get: function() {
                    context["field"] = "securityKey";
                    context["metadata"] = (objectMetadata ? objectMetadata["securityKey"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.securityKey, context);
                },
                set: function(val) {
                    setterFunctions['securityKey'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Otp": {
                get: function() {
                    context["field"] = "Otp";
                    context["metadata"] = (objectMetadata ? objectMetadata["Otp"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Otp, context);
                },
                set: function(val) {
                    setterFunctions['Otp'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "dbpErrCode": {
                get: function() {
                    context["field"] = "dbpErrCode";
                    context["metadata"] = (objectMetadata ? objectMetadata["dbpErrCode"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.dbpErrCode, context);
                },
                set: function(val) {
                    setterFunctions['dbpErrCode'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "dbpErrMsg": {
                get: function() {
                    context["field"] = "dbpErrMsg";
                    context["metadata"] = (objectMetadata ? objectMetadata["dbpErrMsg"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.dbpErrMsg, context);
                },
                set: function(val) {
                    setterFunctions['dbpErrMsg'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "isOtpVerified": {
                get: function() {
                    context["field"] = "isOtpVerified";
                    context["metadata"] = (objectMetadata ? objectMetadata["isOtpVerified"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.isOtpVerified, context);
                },
                set: function(val) {
                    setterFunctions['isOtpVerified'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.userid = value ? (value["userid"] ? value["userid"] : null) : null;
            privateState.password = value ? (value["password"] ? value["password"] : null) : null;
            privateState.temppassword = value ? (value["temppassword"] ? value["temppassword"] : null) : null;
            privateState.resetpassword = value ? (value["resetpassword"] ? value["resetpassword"] : null) : null;
            privateState.status = value ? (value["status"] ? value["status"] : null) : null;
            privateState.retailerid = value ? (value["retailerid"] ? value["retailerid"] : null) : null;
            privateState.retailername = value ? (value["retailername"] ? value["retailername"] : null) : null;
            privateState.role = value ? (value["role"] ? value["role"] : null) : null;
            privateState.phoneno = value ? (value["phoneno"] ? value["phoneno"] : null) : null;
            privateState.emailid = value ? (value["emailid"] ? value["emailid"] : null) : null;
            privateState.username = value ? (value["username"] ? value["username"] : null) : null;
            privateState.securityKey = value ? (value["securityKey"] ? value["securityKey"] : null) : null;
            privateState.Otp = value ? (value["Otp"] ? value["Otp"] : null) : null;
            privateState.dbpErrCode = value ? (value["dbpErrCode"] ? value["dbpErrCode"] : null) : null;
            privateState.dbpErrMsg = value ? (value["dbpErrMsg"] ? value["dbpErrMsg"] : null) : null;
            privateState.isOtpVerified = value ? (value["isOtpVerified"] ? value["isOtpVerified"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Retailer);
    //Create new class level validator object
    BaseModel.Validator.call(Retailer);
    var registerValidatorBackup = Retailer.registerValidator;
    Retailer.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Retailer.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
        //For Operation 'resetPassword' with service id 'ResetPassword7664'
    Retailer.resetPassword = function(params, onCompletion) {
        return Retailer.customVerb('resetPassword', params, onCompletion);
    };
    //For Operation 'modifyUser' with service id 'ModifyUser2473'
    Retailer.modifyUser = function(params, onCompletion) {
        return Retailer.customVerb('modifyUser', params, onCompletion);
    };
    //For Operation 'verifyMFA' with service id 'verifyOTP6897'
    Retailer.verifyMFA = function(params, onCompletion) {
        return Retailer.customVerb('verifyMFA', params, onCompletion);
    };
    //For Operation 'getAllUser' with service id 'getAllUsers5565'
    Retailer.getAllUser = function(params, onCompletion) {
        return Retailer.customVerb('getAllUser', params, onCompletion);
    };
    //For Operation 'createUser' with service id 'CreateNewUser9107'
    Retailer.createUser = function(params, onCompletion) {
        return Retailer.customVerb('createUser', params, onCompletion);
    };
    //For Operation 'requestMFA' with service id 'RequestMFA1401'
    Retailer.requestMFA = function(params, onCompletion) {
        return Retailer.customVerb('requestMFA', params, onCompletion);
    };
    //For Operation 'resendPassword' with service id 'ResendPassword1237'
    Retailer.resendPassword = function(params, onCompletion) {
        return Retailer.customVerb('resendPassword', params, onCompletion);
    };
    var relations = [];
    Retailer.relations = relations;
    Retailer.prototype.isValid = function() {
        return Retailer.isValid(this);
    };
    Retailer.prototype.objModelName = "Retailer";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Retailer.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("RetailerCustomer", "Retailer", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Retailer.clone = function(objectToClone) {
        var clonedObj = new Retailer();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Retailer;
});

define('RetailerCustomer/Retailer/Repository',[], function() {
    var BaseRepository = kony.mvc.Data.BaseRepository;
    //Create the Repository Class
    function RetailerRepository(modelDefinition, config, defaultAppMode, dataSourceFactory, injectedDataSource) {
        BaseRepository.call(this, modelDefinition, config, defaultAppMode, dataSourceFactory, injectedDataSource);
    };
    //Setting BaseRepository as Parent to this Repository
    RetailerRepository.prototype = Object.create(BaseRepository.prototype);
    RetailerRepository.prototype.constructor = RetailerRepository;
    //For Operation 'resetPassword' with service id 'ResetPassword7664'
    RetailerRepository.prototype.resetPassword = function(params, onCompletion) {
        return RetailerRepository.prototype.customVerb('resetPassword', params, onCompletion);
    };
    //For Operation 'modifyUser' with service id 'ModifyUser2473'
    RetailerRepository.prototype.modifyUser = function(params, onCompletion) {
        return RetailerRepository.prototype.customVerb('modifyUser', params, onCompletion);
    };
    //For Operation 'verifyMFA' with service id 'verifyOTP6897'
    RetailerRepository.prototype.verifyMFA = function(params, onCompletion) {
        return RetailerRepository.prototype.customVerb('verifyMFA', params, onCompletion);
    };
    //For Operation 'getAllUser' with service id 'getAllUsers5565'
    RetailerRepository.prototype.getAllUser = function(params, onCompletion) {
        return RetailerRepository.prototype.customVerb('getAllUser', params, onCompletion);
    };
    //For Operation 'createUser' with service id 'CreateNewUser9107'
    RetailerRepository.prototype.createUser = function(params, onCompletion) {
        return RetailerRepository.prototype.customVerb('createUser', params, onCompletion);
    };
    //For Operation 'requestMFA' with service id 'RequestMFA1401'
    RetailerRepository.prototype.requestMFA = function(params, onCompletion) {
        return RetailerRepository.prototype.customVerb('requestMFA', params, onCompletion);
    };
    //For Operation 'resendPassword' with service id 'ResendPassword1237'
    RetailerRepository.prototype.resendPassword = function(params, onCompletion) {
        return RetailerRepository.prototype.customVerb('resendPassword', params, onCompletion);
    };
    return RetailerRepository;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('VoucherObject/voucher/MF_Config',[], function() {
    var mappings = {
        "voucherid": "voucherid",
        "vouchercode": "vouchercode",
        "code": "code",
        "retailerid": "retailerid",
        "status": "status",
        "startdate": "startdate",
        "enddate": "enddate",
        "customerid": "customerid",
        "mobile": "mobile",
    };
    Object.freeze(mappings);
    var typings = {
        "voucherid": "string",
        "vouchercode": "string",
        "code": "string",
        "retailerid": "string",
        "status": "string",
        "startdate": "string",
        "enddate": "string",
        "customerid": "string",
        "mobile": "string",
    }
    Object.freeze(typings);
    var primaryKeys = ["voucherid", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "VoucherObject",
        tableName: "voucher"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('VoucherObject/voucher/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "voucher",
        "objectService": "VoucherObject"
    };
    var setterFunctions = {
        voucherid: function(val, state) {
            context["field"] = "voucherid";
            context["metadata"] = (objectMetadata ? objectMetadata["voucherid"] : null);
            state['voucherid'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        vouchercode: function(val, state) {
            context["field"] = "vouchercode";
            context["metadata"] = (objectMetadata ? objectMetadata["vouchercode"] : null);
            state['vouchercode'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        code: function(val, state) {
            context["field"] = "code";
            context["metadata"] = (objectMetadata ? objectMetadata["code"] : null);
            state['code'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        retailerid: function(val, state) {
            context["field"] = "retailerid";
            context["metadata"] = (objectMetadata ? objectMetadata["retailerid"] : null);
            state['retailerid'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        status: function(val, state) {
            context["field"] = "status";
            context["metadata"] = (objectMetadata ? objectMetadata["status"] : null);
            state['status'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        startdate: function(val, state) {
            context["field"] = "startdate";
            context["metadata"] = (objectMetadata ? objectMetadata["startdate"] : null);
            state['startdate'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        enddate: function(val, state) {
            context["field"] = "enddate";
            context["metadata"] = (objectMetadata ? objectMetadata["enddate"] : null);
            state['enddate'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        customerid: function(val, state) {
            context["field"] = "customerid";
            context["metadata"] = (objectMetadata ? objectMetadata["customerid"] : null);
            state['customerid'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        mobile: function(val, state) {
            context["field"] = "mobile";
            context["metadata"] = (objectMetadata ? objectMetadata["mobile"] : null);
            state['mobile'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function voucher(defaultValues) {
        var privateState = {};
        context["field"] = "voucherid";
        context["metadata"] = (objectMetadata ? objectMetadata["voucherid"] : null);
        privateState.voucherid = defaultValues ? (defaultValues["voucherid"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["voucherid"], context) : null) : null;
        context["field"] = "vouchercode";
        context["metadata"] = (objectMetadata ? objectMetadata["vouchercode"] : null);
        privateState.vouchercode = defaultValues ? (defaultValues["vouchercode"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["vouchercode"], context) : null) : null;
        context["field"] = "code";
        context["metadata"] = (objectMetadata ? objectMetadata["code"] : null);
        privateState.code = defaultValues ? (defaultValues["code"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["code"], context) : null) : null;
        context["field"] = "retailerid";
        context["metadata"] = (objectMetadata ? objectMetadata["retailerid"] : null);
        privateState.retailerid = defaultValues ? (defaultValues["retailerid"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["retailerid"], context) : null) : null;
        context["field"] = "status";
        context["metadata"] = (objectMetadata ? objectMetadata["status"] : null);
        privateState.status = defaultValues ? (defaultValues["status"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["status"], context) : null) : null;
        context["field"] = "startdate";
        context["metadata"] = (objectMetadata ? objectMetadata["startdate"] : null);
        privateState.startdate = defaultValues ? (defaultValues["startdate"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["startdate"], context) : null) : null;
        context["field"] = "enddate";
        context["metadata"] = (objectMetadata ? objectMetadata["enddate"] : null);
        privateState.enddate = defaultValues ? (defaultValues["enddate"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["enddate"], context) : null) : null;
        context["field"] = "customerid";
        context["metadata"] = (objectMetadata ? objectMetadata["customerid"] : null);
        privateState.customerid = defaultValues ? (defaultValues["customerid"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["customerid"], context) : null) : null;
        context["field"] = "mobile";
        context["metadata"] = (objectMetadata ? objectMetadata["mobile"] : null);
        privateState.mobile = defaultValues ? (defaultValues["mobile"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["mobile"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "voucherid": {
                get: function() {
                    context["field"] = "voucherid";
                    context["metadata"] = (objectMetadata ? objectMetadata["voucherid"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.voucherid, context);
                },
                set: function(val) {
                    setterFunctions['voucherid'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "vouchercode": {
                get: function() {
                    context["field"] = "vouchercode";
                    context["metadata"] = (objectMetadata ? objectMetadata["vouchercode"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.vouchercode, context);
                },
                set: function(val) {
                    setterFunctions['vouchercode'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "code": {
                get: function() {
                    context["field"] = "code";
                    context["metadata"] = (objectMetadata ? objectMetadata["code"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.code, context);
                },
                set: function(val) {
                    setterFunctions['code'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "retailerid": {
                get: function() {
                    context["field"] = "retailerid";
                    context["metadata"] = (objectMetadata ? objectMetadata["retailerid"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.retailerid, context);
                },
                set: function(val) {
                    setterFunctions['retailerid'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "status": {
                get: function() {
                    context["field"] = "status";
                    context["metadata"] = (objectMetadata ? objectMetadata["status"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.status, context);
                },
                set: function(val) {
                    setterFunctions['status'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "startdate": {
                get: function() {
                    context["field"] = "startdate";
                    context["metadata"] = (objectMetadata ? objectMetadata["startdate"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.startdate, context);
                },
                set: function(val) {
                    setterFunctions['startdate'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "enddate": {
                get: function() {
                    context["field"] = "enddate";
                    context["metadata"] = (objectMetadata ? objectMetadata["enddate"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.enddate, context);
                },
                set: function(val) {
                    setterFunctions['enddate'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "customerid": {
                get: function() {
                    context["field"] = "customerid";
                    context["metadata"] = (objectMetadata ? objectMetadata["customerid"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.customerid, context);
                },
                set: function(val) {
                    setterFunctions['customerid'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "mobile": {
                get: function() {
                    context["field"] = "mobile";
                    context["metadata"] = (objectMetadata ? objectMetadata["mobile"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.mobile, context);
                },
                set: function(val) {
                    setterFunctions['mobile'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.voucherid = value ? (value["voucherid"] ? value["voucherid"] : null) : null;
            privateState.vouchercode = value ? (value["vouchercode"] ? value["vouchercode"] : null) : null;
            privateState.code = value ? (value["code"] ? value["code"] : null) : null;
            privateState.retailerid = value ? (value["retailerid"] ? value["retailerid"] : null) : null;
            privateState.status = value ? (value["status"] ? value["status"] : null) : null;
            privateState.startdate = value ? (value["startdate"] ? value["startdate"] : null) : null;
            privateState.enddate = value ? (value["enddate"] ? value["enddate"] : null) : null;
            privateState.customerid = value ? (value["customerid"] ? value["customerid"] : null) : null;
            privateState.mobile = value ? (value["mobile"] ? value["mobile"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(voucher);
    //Create new class level validator object
    BaseModel.Validator.call(voucher);
    var registerValidatorBackup = voucher.registerValidator;
    voucher.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (voucher.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
        //For Operation 'getVoucherList' with service id 'dbxdb_sp_get_voucher_ids_by_retailerID9307'
    voucher.getVoucherList = function(params, onCompletion) {
        return voucher.customVerb('getVoucherList', params, onCompletion);
    };
    //For Operation 'generateVoucher' with service id 'GenerateVoucher2560'
    voucher.generateVoucher = function(params, onCompletion) {
        return voucher.customVerb('generateVoucher', params, onCompletion);
    };
    //For Operation 'getVoucherMI' with service id 'dbxdb_sp_get_vouchermi4180'
    voucher.getVoucherMI = function(params, onCompletion) {
        return voucher.customVerb('getVoucherMI', params, onCompletion);
    };
    //For Operation 'getVoucherDetails' with service id 'GetVoucherByCodeOrNumber7141'
    voucher.getVoucherDetails = function(params, onCompletion) {
        return voucher.customVerb('getVoucherDetails', params, onCompletion);
    };
    //For Operation 'redeemVoucher' with service id 'RedeemVoucher3475'
    voucher.redeemVoucher = function(params, onCompletion) {
        return voucher.customVerb('redeemVoucher', params, onCompletion);
    };
    var relations = [];
    voucher.relations = relations;
    voucher.prototype.isValid = function() {
        return voucher.isValid(this);
    };
    voucher.prototype.objModelName = "voucher";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    voucher.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("VoucherObject", "voucher", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    voucher.clone = function(objectToClone) {
        var clonedObj = new voucher();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return voucher;
});

define('VoucherObject/voucher/Repository',[], function() {
    var BaseRepository = kony.mvc.Data.BaseRepository;
    //Create the Repository Class
    function voucherRepository(modelDefinition, config, defaultAppMode, dataSourceFactory, injectedDataSource) {
        BaseRepository.call(this, modelDefinition, config, defaultAppMode, dataSourceFactory, injectedDataSource);
    };
    //Setting BaseRepository as Parent to this Repository
    voucherRepository.prototype = Object.create(BaseRepository.prototype);
    voucherRepository.prototype.constructor = voucherRepository;
    //For Operation 'getVoucherList' with service id 'dbxdb_sp_get_voucher_ids_by_retailerID9307'
    voucherRepository.prototype.getVoucherList = function(params, onCompletion) {
        return voucherRepository.prototype.customVerb('getVoucherList', params, onCompletion);
    };
    //For Operation 'generateVoucher' with service id 'GenerateVoucher2560'
    voucherRepository.prototype.generateVoucher = function(params, onCompletion) {
        return voucherRepository.prototype.customVerb('generateVoucher', params, onCompletion);
    };
    //For Operation 'getVoucherMI' with service id 'dbxdb_sp_get_vouchermi4180'
    voucherRepository.prototype.getVoucherMI = function(params, onCompletion) {
        return voucherRepository.prototype.customVerb('getVoucherMI', params, onCompletion);
    };
    //For Operation 'getVoucherDetails' with service id 'GetVoucherByCodeOrNumber7141'
    voucherRepository.prototype.getVoucherDetails = function(params, onCompletion) {
        return voucherRepository.prototype.customVerb('getVoucherDetails', params, onCompletion);
    };
    //For Operation 'redeemVoucher' with service id 'RedeemVoucher3475'
    voucherRepository.prototype.redeemVoucher = function(params, onCompletion) {
        return voucherRepository.prototype.customVerb('redeemVoucher', params, onCompletion);
    };
    return voucherRepository;
})
;
define('AuthManager/BusinessControllers/BusinessController',[], function() {
    /**
     * User defined business controller
     * @constructor
     * @extends kony.mvc.Business.Delegator
     */
    function AuthManager() {
        kony.mvc.Business.Delegator.call(this);
    }
    inheritsFrom(AuthManager, kony.mvc.Business.Delegator);
    AuthManager.prototype.login = function(params, sucessCB, errorCB) {
        //     var authParams = {
        //       "userid": params.username,
        //       "password": params.password
        //     };
        var authParams = {
            "UserName": params.username,
            "Password": params.password
        };
        authClient = KNYMobileFabric.getIdentityService("MoraRetailerLogin");
        authClient.login(authParams, successCallback, failureCallback);

        function successCallback() {
            authClient.getUserAttributes(sucessCB.bind(this), errorCB.bind(this));
        }

        function failureCallback(resError) {
            errorCB(resError);
        }
    };
    AuthManager.prototype.logout = function(sucessCB, errorCB) {
        authClient = KNYMobileFabric.getIdentityService("MoraRetailerLogin");
        authClient.logout(successCallback, failureCallback);

        function successCallback(resSuccess) {
            sucessCB(resSuccess);
        }

        function failureCallback(resError) {
            errorCB(resError);
        }
    };
    AuthManager.prototype.resetPassword = function(params, sucessCB, errorCB) {
        var self = this;
        var userRepo =  kony.mvc.MDAApplication.getSharedInstance().getRepoManager().getRepository("Retailer");
        userRepo.customVerb('resetPassword', params, serviceCompletionCallback);

        function serviceCompletionCallback(status, data, error) {
            //alert("status"+status+" data "+data+" error "+error)
            if (data.opstatus === 0) {
                if (data.hasOwnProperty("dbpErrCode") || data.hasOwnProperty("dbpErrMsg")) {
                    failureCallback(data);
                } else {
                    successCallback(data);
                }
            }
        }

        function successCallback(resSucess) {
            sucessCB(resSucess);
        }

        function failureCallback(resError) {
            errorCB(resError);
        }
    };
    AuthManager.prototype.resendPassword = function(params, sucessCB, errorCB) {
        var self = this;
        var userRepo =  kony.mvc.MDAApplication.getSharedInstance().getRepoManager().getRepository("Retailer");
        userRepo.customVerb('resendPassword', params, serviceCompletionCallback);

        function serviceCompletionCallback(status, data, error) {
            //alert("status"+status+" data "+data+" error "+error)
            if (data.opstatus === 0) {
                if (data.hasOwnProperty("dbpErrCode") || data.hasOwnProperty("dbpErrMsg")) {
                    failureCallback(data);
                } else {
                    successCallback(data);
                }
            }
        }

        function successCallback(resSucess) {
            sucessCB(resSucess);
        }

        function failureCallback(resError) {
            errorCB(resError);
        }
    };
    AuthManager.prototype.requestMFA = function(params, sucessCB, errorCB) {
        var self = this;
        var userRepo =  kony.mvc.MDAApplication.getSharedInstance().getRepoManager().getRepository("Retailer");
        userRepo.customVerb('requestMFA', params, serviceCompletionCallback);

        function serviceCompletionCallback(status, data, error) {
            //alert("status"+status+" data "+data+" error "+error)
            if (data.opstatus === 0) {
                if (data.hasOwnProperty("dbpErrCode") || data.hasOwnProperty("dbpErrMsg")) {
                    failureCallback(data);
                } else {
                    successCallback(data);
                }
            }
        }

        function successCallback(resSucess) {
            sucessCB(resSucess);
        }

        function failureCallback(resError) {
            errorCB(resError);
        }
    };
    AuthManager.prototype.verifyMFA = function(params, sucessCB, errorCB) {
        var self = this;
        var userRepo =  kony.mvc.MDAApplication.getSharedInstance().getRepoManager().getRepository("Retailer");
        userRepo.customVerb('verifyMFA', params, serviceCompletionCallback);

        function serviceCompletionCallback(status, data, error) {
            //alert("status"+status+" data "+data+" error "+error)
            if (data.opstatus === 0) {
                if (data.hasOwnProperty("dbpErrCode") || data.hasOwnProperty("dbpErrMsg")) {
                    failureCallback(data);
                } else {
                    successCallback(data);
                }
            }
        }

        function successCallback(resSucess) {
            sucessCB(resSucess);
        }

        function failureCallback(resError) {
            errorCB(resError);
        }
    };
    return AuthManager;
});

define('AuthModule/PresentationControllers/PresentationController',[], function() {
    /**
     * User defined presentation controller
     * @constructor
     * @extends kony.mvc.Presentation.BasePresenter
     */
    function PresentationController() {
        kony.mvc.Presentation.BasePresenter.call(this);
    }
    inheritsFrom(PresentationController, kony.mvc.Presentation.BasePresenter);
    /**
     * Overridden Method of kony.mvc.Presentation.BasePresenter
     * This method gets called when presentation controller gets initialized
     * @method
     */
    PresentationController.prototype.initializePresentationController = function() {};
    return PresentationController;
});

define('RetailerManager/BusinessControllers/BusinessController',[], function() {
    /**
     * User defined business controller
     * @constructor
     * @extends kony.mvc.Business.Delegator
     */
    function RetailerManager() {
        kony.mvc.Business.Delegator.call(this);
    }
    inheritsFrom(RetailerManager, kony.mvc.Business.Delegator);
    RetailerManager.prototype.createUser = function(params, sucessCB, errorCB) {
        var self = this;
        var userRepo =  kony.mvc.MDAApplication.getSharedInstance().getRepoManager().getRepository("Retailer");
        userRepo.customVerb('createUser', params, serviceCompletionCallback);

        function serviceCompletionCallback(status, data, error) {
            //alert("status"+status+" data "+data+" error "+error);
            if (data && data.opstatus === 0) {
                if (data.hasOwnProperty("dbpErrCode") || data.hasOwnProperty("dbpErrMsg")) {
                    failureCallback(data);
                } else {
                    successCallback(data);
                }
            } else {
                failureCallback(error);
            }
        }

        function successCallback(resSucess) {
            sucessCB(resSucess);
        }

        function failureCallback(resError) {
            errorCB(resError);
        }
    };
    RetailerManager.prototype.modifyUser = function(params, sucessCB, errorCB) {
        var self = this;
        var userRepo =  kony.mvc.MDAApplication.getSharedInstance().getRepoManager().getRepository("Retailer");
        userRepo.customVerb('modifyUser', params, serviceCompletionCallback);

        function serviceCompletionCallback(status, data, error) {
            //alert("status"+status+" data "+data+" error "+error);
            if (data && data.opstatus === 0) {
                if (data.hasOwnProperty("dbpErrCode") || data.hasOwnProperty("dbpErrMsg")) {
                    failureCallback(data);
                } else {
                    successCallback(data);
                }
            } else {
                failureCallback(error);
            }
        }

        function successCallback(resSucess) {
            sucessCB(resSucess);
        }

        function failureCallback(resError) {
            errorCB(resError);
        }
    };
    RetailerManager.prototype.getAllUser = function(params, sucessCB, errorCB) {
        var self = this;
        var userRepo =  kony.mvc.MDAApplication.getSharedInstance().getRepoManager().getRepository("Retailer");
        userRepo.customVerb('getAllUser', params, serviceCompletionCallback);

        function serviceCompletionCallback(status, data, error) {
            //alert("status"+status+" data "+data+" error "+error);
            if (data && data.opstatus === 0) {
                if (data.hasOwnProperty("dbpErrCode") || data.hasOwnProperty("dbpErrMsg")) {
                    failureCallback(data);
                } else {
                    successCallback(data);
                }
            } else {
                failureCallback(error);
            }
        }

        function successCallback(resSucess) {
            sucessCB(resSucess);
        }

        function failureCallback(resError) {
            errorCB(resError);
        }
    };
    return RetailerManager;
});

define('VoucherManager/BusinessControllers/BusinessController',[], function() {
    /**
     * User defined business controller
     * @constructor
     * @extends kony.mvc.Business.Delegator
     */
    function VoucherManager() {
        kony.mvc.Business.Delegator.call(this);
    }
    inheritsFrom(VoucherManager, kony.mvc.Business.Delegator);
    VoucherManager.prototype.getVoucherList = function(params, sucessCB, errorCB) {
        var self = this;
        var userRepo =  kony.mvc.MDAApplication.getSharedInstance().getRepoManager().getRepository("voucher");
        userRepo.customVerb('getVoucherList', params, serviceCompletionCallback);

        function serviceCompletionCallback(status, data, error) {
            //alert("status"+status+" data "+data+" error "+error);
            if (data && data.opstatus === 0) {
                if (data.hasOwnProperty("dbpErrCode") || data.hasOwnProperty("dbpErrMsg")) {
                    failureCallback(data);
                } else {
                    successCallback(data);
                }
            } else {
                failureCallback(error);
            }
        }

        function successCallback(resSucess) {
            sucessCB(resSucess);
        }

        function failureCallback(resError) {
            errorCB(resError);
        }
    };
    VoucherManager.prototype.getVoucherDetails = function(params, sucessCB, errorCB) {
        var self = this;
        var userRepo =  kony.mvc.MDAApplication.getSharedInstance().getRepoManager().getRepository("voucher");
        userRepo.customVerb('getVoucherDetails', params, serviceCompletionCallback);

        function serviceCompletionCallback(status, data, error) {
            //alert("status"+status+" data "+data+" error "+error);
            if (data && data.opstatus === 0) {
                if (data.hasOwnProperty("dbpErrCode") || data.hasOwnProperty("dbpErrMsg")) {
                    failureCallback(data);
                } else {
                    successCallback(data);
                }
            } else {
                failureCallback(error);
            }
        }

        function successCallback(resSucess) {
            sucessCB(resSucess);
        }

        function failureCallback(resError) {
            errorCB(resError);
        }
    };
    VoucherManager.prototype.redeemVoucher = function(params, sucessCB, errorCB) {
        var self = this;
        var userRepo =  kony.mvc.MDAApplication.getSharedInstance().getRepoManager().getRepository("voucher");
        userRepo.customVerb('redeemVoucher', params, serviceCompletionCallback);

        function serviceCompletionCallback(status, data, error) {
            //alert("status"+status+" data "+data+" error "+error);
            if (data) {
                if (data.hasOwnProperty("dbpErrCode") || data.hasOwnProperty("dbpErrMsg")) {
                    failureCallback(data);
                } else {
                    successCallback(data);
                }
            } else {
                failureCallback(data);
            }
        }

        function successCallback(resSucess) {
            sucessCB(resSucess);
        }

        function failureCallback(resError) {
            errorCB(resError);
        }
    };
    VoucherManager.prototype.getVoucherMIList = function(params, sucessCB, errorCB) {
        var self = this;
        var userRepo =  kony.mvc.MDAApplication.getSharedInstance().getRepoManager().getRepository("voucher");
        userRepo.customVerb('getVoucherMI', params, serviceCompletionCallback);

        function serviceCompletionCallback(status, data, error) {
            //alert("status"+status+" data "+data+" error "+error);
            if (data && data.opstatus === 0) {
                if (data.hasOwnProperty("dbpErrCode") || data.hasOwnProperty("dbpErrMsg")) {
                    failureCallback(data);
                } else {
                    successCallback(data);
                }
            } else {
                failureCallback(error);
            }
        }

        function successCallback(resSucess) {
            sucessCB(resSucess);
        }

        function failureCallback(resError) {
            errorCB(resError);
        }
    };
    return VoucherManager;
});

require(['applicationController','com/HeaderComponent/HeaderComponentController','com/HeaderComponent/HeaderComponent','com/HeaderComponentPostLogin/HeaderComponentPostLoginController','com/HeaderComponentPostLogin/HeaderComponentPostLogin','com/leftpane/leftpaneController','com/leftpane/leftpane','flxSampleRowTemplate','flxSectionHeaderTemplate','flxUserList','flxVoucherHeader','flxSegVoucherList','flxSampleRowTemplateController','flxSectionHeaderTemplateController','flxUserListController','flxVoucherHeaderController','flxSegVoucherListController','navigation/NavigationModel','navigation/NavigationController','RepoManagerConfig','RetailerCustomer/Retailer/MF_Config','RetailerCustomer/Retailer/Model','RetailerCustomer/Retailer/Repository','VoucherObject/voucher/MF_Config','VoucherObject/voucher/Model','VoucherObject/voucher/Repository','AuthManager/BusinessControllers/BusinessController','AuthModule/PresentationControllers/PresentationController','RetailerManager/BusinessControllers/BusinessController','VoucherManager/BusinessControllers/BusinessController'], function(){});

define("sparequirefileslist", function(){});

