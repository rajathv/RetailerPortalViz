define("Authentication/frmLogin", function() {
    return function(controller) {
        function addWidgetsfrmLogin() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknflxscrollbggrey",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "10%",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var HeaderComponent = new com.HeaderComponent({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "HeaderComponent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan",
                "overrides": {
                    "HeaderComponent": {
                        "height": "100%"
                    },
                    "Image0ed0f18d8ce2b4b": {
                        "src": "logo1x.png"
                    },
                    "flxHeader": {
                        "height": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(HeaderComponent);
            var flxContainerSection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "613px",
                "id": "flxContainerSection",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sKnflxGreyBorder25px",
                "top": "157px",
                "width": "90%",
                "zIndex": 2,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxContainerSection.setDefaultUnit(kony.flex.DP);
            var flxLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "45%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var lblRetailPrtner = new kony.ui.Label({
                "id": "lblRetailPrtner",
                "isVisible": true,
                "left": "90px",
                "skin": "sknlbl18pxCalibriGrey",
                "text": "RETAIL PATNER PORTAL",
                "top": "60px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLoginContenet = new kony.ui.Label({
                "id": "lblLoginContenet",
                "isVisible": true,
                "left": "90px",
                "skin": "sknlbl2c3d7335pxBold",
                "text": "Please Introduce your credentials to login in the retail patner portal.",
                "top": "85px",
                "width": "350px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgLogin = new kony.ui.Image2({
                "bottom": "120px",
                "height": "260dp",
                "id": "imgLogin",
                "isVisible": true,
                "left": "145px",
                "skin": "slImage",
                "src": "login1x.png",
                "width": "227dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLeft.add(lblRetailPrtner, lblLoginContenet, imgLogin);
            var flxRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "478px",
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "90px",
                "skin": "sknflxGreyBGBorder30PX",
                "top": "60px",
                "width": "530px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxEmailorPhone = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxEmailorPhone",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "15%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "90px",
                "width": "354px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmailorPhone.setDefaultUnit(kony.flex.DP);
            var lblEmailPhone = new kony.ui.Label({
                "id": "lblEmailPhone",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px20",
                "text": "USER ID",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtEmailorPhone = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtEmailorPhone",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Please enter email or mobile number",
                "secureTextEntry": false,
                "skin": "skntxtboxwhiterounded",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxEmailorPhone.add(lblEmailPhone, txtEmailorPhone);
            var flxPassword = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxPassword",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "15%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30px",
                "width": "354px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxPassword.setDefaultUnit(kony.flex.DP);
            var lblPassword = new kony.ui.Label({
                "id": "lblPassword",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl2c3d73px20",
                "text": "PASSWORD",
                "top": "0dp",
                "width": "150px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtPassword = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtPassword",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Please type in your password",
                "secureTextEntry": true,
                "skin": "skntxtboxwhiterounded",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxPassword.add(lblPassword, txtPassword);
            var btnForgotPassword = new kony.ui.Button({
                "id": "btnForgotPassword",
                "isVisible": false,
                "right": "90px",
                "skin": "btn2c3d73greyBG",
                "text": "Forgotton Password?",
                "top": "10px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxError = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxError",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "15%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20px",
                "width": "354px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxError.setDefaultUnit(kony.flex.DP);
            var lblError1 = new kony.ui.Label({
                "id": "lblError1",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblFF4D56px13ErrorMsg",
                "text": "Wrong credentials Entered.",
                "top": "0dp",
                "width": "300px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblError2 = new kony.ui.Label({
                "id": "lblError2",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblFF4D56px13ErrorMsg",
                "text": "Please enter correct EMAIL or MOBILE NUMBER",
                "top": "5dp",
                "width": "300px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblError3 = new kony.ui.Label({
                "id": "lblError3",
                "isVisible": false,
                "left": "0dp",
                "skin": "sknlblFF4D56px13ErrorMsg",
                "text": "Forgot password? Click Forgotten password?.",
                "top": "5dp",
                "width": "300px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxError.add(lblError1, lblError2, lblError3);
            var btnContinue = new kony.ui.Button({
                "bottom": 10,
                "height": "50dp",
                "id": "btnContinue",
                "isVisible": true,
                "right": "80px",
                "skin": "sknbtn2c3d73Rounded18px",
                "text": "Continue    >",
                "top": "20px",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRight.add(flxEmailorPhone, flxPassword, btnForgotPassword, flxError, btnContinue);
            flxContainerSection.add(flxLeft, flxRight);
            var imgBackground = new kony.ui.Image2({
                "height": "1128px",
                "id": "imgBackground",
                "isVisible": true,
                "right": "-5%",
                "skin": "slImage",
                "src": "background1x.png",
                "top": "-239px",
                "width": "1156px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMain.add(flxHeader, flxContainerSection, imgBackground);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "HeaderComponent": {
                    "height": "100%"
                },
                "HeaderComponent.Image0ed0f18d8ce2b4b": {
                    "src": "logo1x.png"
                },
                "HeaderComponent.flxHeader": {
                    "height": "100%"
                }
            }
            this.add(flxMain);
        };
        return [{
            "addWidgets": addWidgetsfrmLogin,
            "enabledForIdleTimeout": false,
            "id": "frmLogin",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "preShow": function(eventobject) {
                controller.AS_Form_i5477a3403134bbb98b3bb7774892d4e(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "MurahabaLoan"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_fcd8b0aa09ea423e9c1e6fd4a2e95883,
            "retainScrollPosition": false
        }]
    }
});