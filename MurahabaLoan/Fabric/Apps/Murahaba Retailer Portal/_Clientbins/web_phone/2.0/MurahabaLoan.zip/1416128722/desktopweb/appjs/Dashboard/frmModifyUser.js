define("Dashboard/frmModifyUser", function() {
    return function(controller) {
        function addWidgetsfrmModifyUser() {
            this.setDefaultUnit(kony.flex.DP);
            var HeaderComponentPostLogin = new com.HeaderComponentPostLogin({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100px",
                "id": "HeaderComponentPostLogin",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slnflxbottomGreyBorder",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "MurahabaLoan",
                "overrides": {
                    "HeaderComponentPostLogin": {
                        "height": "100px",
                        "zIndex": 3
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var leftpane = new com.leftpane({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "924px",
                "id": "leftpane",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "100px",
                "width": "300px",
                "zIndex": 3,
                "appName": "MurahabaLoan",
                "overrides": {
                    "flxCreateNewUser": {
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxHomePage": {
                        "top": "150px",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxLine1": {
                        "isVisible": false
                    },
                    "flxLine2": {
                        "isVisible": false
                    },
                    "flxLine3": {
                        "isVisible": true
                    },
                    "lblCreateNewUser": {
                        "isVisible": true,
                        "left": "48dp",
                        "top": "viz.val_cleared"
                    },
                    "lblHomePage": {
                        "left": "48dp"
                    },
                    "leftpane": {
                        "height": "924px",
                        "top": "100px",
                        "width": "300px",
                        "zIndex": 3
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxRightPane = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "924px",
                "id": "flxRightPane",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "300px",
                "isModalContainer": false,
                "skin": "sknflxbggrey",
                "top": "100px",
                "width": "78%",
                "zIndex": 2,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightPane.setDefaultUnit(kony.flex.DP);
            var imgBg = new kony.ui.Image2({
                "height": "1000px",
                "id": "imgBg",
                "isVisible": false,
                "left": "50px",
                "skin": "slImage",
                "src": "background1x.png",
                "top": "-239dp",
                "width": "1156px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUserSearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "855px",
                "id": "flxUserSearch",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1064px",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserSearch.setDefaultUnit(kony.flex.DP);
            var flxTopHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTopHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopHeader.setDefaultUnit(kony.flex.DP);
            var lblRetailPartnerPortal = new kony.ui.Label({
                "id": "lblRetailPartnerPortal",
                "isVisible": true,
                "left": "70px",
                "skin": "sknlblF0ECE9px40",
                "text": "RETAIL PATNER PORTAL",
                "top": "90px",
                "width": "521px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTopHeader.add(lblRetailPartnerPortal);
            var flxSearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "70px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30px",
                "width": "490px",
                "zIndex": 2,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearch.setDefaultUnit(kony.flex.DP);
            var txtSearchUser = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "skntxtboxwhiterounded2c3d73border",
                "height": "40dp",
                "id": "txtSearchUser",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "Please enter User ID, Mobile Number or Email ID ",
                "secureTextEntry": false,
                "skin": "skntxtboxwhiterounded2c3d73border",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "490px",
                "zIndex": 2
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false
            });
            var flxSearchIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "50%",
                "id": "flxSearchIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "5%",
                "skin": "slFbox",
                "top": "0",
                "width": "10%",
                "zIndex": 2,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchIcon.setDefaultUnit(kony.flex.DP);
            var imgSearch = new kony.ui.Image2({
                "height": "100%",
                "id": "imgSearch",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "search1x.png",
                "top": "0dp",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchIcon.add(imgSearch);
            flxSearch.add(txtSearchUser, flxSearchIcon);
            var flxSegmentSearchList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "470px",
                "id": "flxSegmentSearchList",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "70px",
                "isModalContainer": false,
                "skin": "sKnflx2C3D73ShadowRounded",
                "top": "-30px",
                "width": "490px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegmentSearchList.setDefaultUnit(kony.flex.DP);
            var segUsers = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }, {
                    "lblUserName": "Label"
                }],
                "groupCells": false,
                "height": "92%",
                "id": "segUsers",
                "isVisible": true,
                "left": "8dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "segRoundedCornerpx30",
                "rowTemplate": "flxUserList",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "e4e4e433",
                "separatorRequired": true,
                "showScrollbars": false,
                "top": "25dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxUserList": "flxUserList",
                    "lblUserName": "lblUserName"
                },
                "width": "95.92%",
                "appName": "MurahabaLoan"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegmentSearchList.add(segUsers);
            flxUserSearch.add(flxTopHeader, flxSearch, flxSegmentSearchList);
            var flxUserDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "855px",
                "id": "flxUserDetails",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxWhiteBGBorderpx30",
                "top": "50dp",
                "width": "92%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserDetails.setDefaultUnit(kony.flex.DP);
            var flxTopContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxTopContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopContent.setDefaultUnit(kony.flex.DP);
            var lblRetailPrtner = new kony.ui.Label({
                "id": "lblRetailPrtner",
                "isVisible": true,
                "left": "70px",
                "skin": "sknlbl18pxCalibriGrey",
                "text": "RETAIL PATNER PORTAL",
                "top": "60px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUserDetails = new kony.ui.Label({
                "id": "lblUserDetails",
                "isVisible": true,
                "left": "70px",
                "skin": "sknlbl2c3d73px22",
                "text": "User Details",
                "top": "90px",
                "width": "80%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40%",
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "10dp",
                "skin": "slFbox",
                "top": "10dp",
                "width": "6%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "height": "100%",
                "id": "imgClose",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "close1x.png",
                "top": "0dp",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnClose = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "100%",
                "id": "btnClose",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknbtntrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClose.add(imgClose, btnClose);
            flxTopContent.add(lblRetailPrtner, lblUserDetails, flxClose);
            var flxUserDetailsSection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "586px",
                "id": "flxUserDetailsSection",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknflxGreyBGBorder30PX",
                "top": "175dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserDetailsSection.setDefaultUnit(kony.flex.DP);
            var flxLine1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "72dp",
                "id": "flxLine1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "zIndex": 20,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxLine1.setDefaultUnit(kony.flex.DP);
            var flxUsername = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxUsername",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "354px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxUsername.setDefaultUnit(kony.flex.DP);
            var lblUsername = new kony.ui.Label({
                "id": "lblUsername",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px22bold",
                "text": "USER NAME",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtUsername = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtUsername",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Enter user name",
                "secureTextEntry": false,
                "skin": "skntxtboxwhiterounded",
                "text": "Muhammed",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxUsername.add(lblUsername, txtUsername);
            var flxRole = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxRole",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "50px",
                "skin": "slFbox",
                "top": "0px",
                "width": "354px",
                "zIndex": 20,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxRole.setDefaultUnit(kony.flex.DP);
            var lblRole = new kony.ui.Label({
                "id": "lblRole",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px22bold",
                "text": "ROLE",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtRole = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtRole",
                "isVisible": false,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Please select role from drop down",
                "secureTextEntry": false,
                "skin": "skntxtboxwhiterounded",
                "text": "Sles Person",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var flxRoleSelection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxRoleSelection",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknwhitebgroundedcorner",
                "top": "5dp",
                "width": "354dp",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxRoleSelection.setDefaultUnit(kony.flex.DP);
            var lblRoleSelection = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblRoleSelection",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknlbl18px6A7E9B",
                "text": "Please select role from drop down",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgArrow = new kony.ui.Image2({
                "centerY": "50%",
                "height": "15dp",
                "id": "imgArrow",
                "isVisible": true,
                "right": "20dp",
                "skin": "slImage",
                "src": "downarrow1x.png",
                "top": "15dp",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnRoleSelection = new kony.ui.Button({
                "height": "100%",
                "id": "btnRoleSelection",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknbtntrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRoleSelection.add(lblRoleSelection, imgArrow, btnRoleSelection);
            var flxSegRole = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0",
                "clipBounds": false,
                "height": "150px",
                "id": "flxSegRole",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3.12%",
                "isModalContainer": false,
                "skin": "sKnflx2C3D73ShadowRoundedBottom",
                "top": "0%",
                "width": "340px",
                "zIndex": 20,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegRole.setDefaultUnit(kony.flex.DP);
            var segRole = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblUserName": "Sale Representative"
                }, {
                    "lblUserName": "Sale Person"
                }],
                "groupCells": false,
                "height": "95.53%",
                "id": "segRole",
                "isVisible": true,
                "left": "8dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "segRoundedCornerpx30",
                "rowTemplate": "flxUserList",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": true,
                "showScrollbars": false,
                "top": "11dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxUserList": "flxUserList",
                    "lblUserName": "lblUserName"
                },
                "width": "95.92%",
                "zIndex": 20,
                "appName": "MurahabaLoan"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegRole.add(segRole);
            flxRole.add(lblRole, txtRole, flxRoleSelection, flxSegRole);
            flxLine1.add(flxUsername, flxRole);
            var flxLine2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "72dp",
                "id": "flxLine2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "50dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxLine2.setDefaultUnit(kony.flex.DP);
            var flxPhoneNumber = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxPhoneNumber",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "354px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhoneNumber.setDefaultUnit(kony.flex.DP);
            var lblPhoneNumber = new kony.ui.Label({
                "id": "lblPhoneNumber",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px22bold",
                "text": "PHONE NUMBER",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtPhoneNumber = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtPhoneNumber",
                "isVisible": false,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "00000000000",
                "secureTextEntry": false,
                "skin": "skntxtboxwhiterounded",
                "text": "+966 9876543210",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var flxPhoneGroup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxPhoneGroup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "flxsknLblasTxtLook",
                "top": "10dp",
                "width": "354px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhoneGroup.setDefaultUnit(kony.flex.DP);
            var lblCountryCode = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCountryCode",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl2c3d7320px",
                "text": "+966",
                "top": "0",
                "width": "50px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtPhoneNo = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "skntxtNoFocus",
                "height": "40dp",
                "id": "txtPhoneNo",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "50dp",
                "maxTextLength": 10,
                "placeholder": "Enter Phone Number",
                "secureTextEntry": false,
                "skin": "skntxtboxwhiterounded",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0px",
                "width": "300px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxPhoneGroup.add(lblCountryCode, txtPhoneNo);
            flxPhoneNumber.add(lblPhoneNumber, txtPhoneNumber, flxPhoneGroup);
            var flxEmail = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxEmail",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "50px",
                "skin": "slFbox",
                "top": "0px",
                "width": "354px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmail.setDefaultUnit(kony.flex.DP);
            var lblEmail = new kony.ui.Label({
                "id": "lblEmail",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px22bold",
                "text": "EMAIL",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtEmail = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtEmail",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "example@mail.com",
                "secureTextEntry": false,
                "skin": "skntxtboxwhiterounded",
                "text": "example@mail.com",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxEmail.add(lblEmail, txtEmail);
            flxLine2.add(flxPhoneNumber, flxEmail);
            var flxLine3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "72dp",
                "id": "flxLine3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "50dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxLine3.setDefaultUnit(kony.flex.DP);
            var flxUserId = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxUserId",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "50dp",
                "skin": "slFbox",
                "top": "0px",
                "width": "354px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserId.setDefaultUnit(kony.flex.DP);
            var lblUserId = new kony.ui.Label({
                "id": "lblUserId",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px22bold",
                "text": "USER ID",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtUserId = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtUserId",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Enter user ID",
                "secureTextEntry": false,
                "skin": "skntxtboxE8E8E8rounded",
                "text": "Muhib22",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxUserId.add(lblUserId, txtUserId);
            var flxStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxStatus",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5%",
                "isModalContainer": false,
                "right": "50px",
                "skin": "slFbox",
                "top": "0px",
                "width": "354px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxStatus.setDefaultUnit(kony.flex.DP);
            var lblStatus = new kony.ui.Label({
                "id": "lblStatus",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl2c3d73px22bold",
                "text": "STATUS",
                "top": "0dp",
                "width": "200px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtStatus = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "txtStatus",
                "isVisible": false,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "example@mail.com",
                "secureTextEntry": false,
                "skin": "skntxtboxwhiterounded",
                "text": "Active",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10px",
                "width": "354px"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lstboxstatus = new kony.ui.ListBox({
                "height": "40dp",
                "id": "lstboxstatus",
                "isVisible": false,
                "left": "0",
                "masterData": [
                    ["1", "Active"],
                    ["2", "unactive"]
                ],
                "right": "0",
                "selectedKey": "1",
                "skin": "sknlstwhieborder",
                "top": "10dp",
                "width": "354dp",
                "zIndex": 1,
                "blur": {
                    "enabled": false,
                    "value": 0
                }
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var flxStatusSelection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxStatusSelection",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknwhitebgroundedcorner",
                "top": "5dp",
                "width": "354dp",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxStatusSelection.setDefaultUnit(kony.flex.DP);
            var lblActiveSelection = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblActiveSelection",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknlbl18px6A7E9B",
                "text": "Active",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgActiveArrow = new kony.ui.Image2({
                "centerY": "50%",
                "height": "15dp",
                "id": "imgActiveArrow",
                "isVisible": true,
                "right": "20dp",
                "skin": "slImage",
                "src": "downarrow1x.png",
                "top": "15dp",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnStatusSelection = new kony.ui.Button({
                "height": "100%",
                "id": "btnStatusSelection",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknbtntrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxStatusSelection.add(lblActiveSelection, imgActiveArrow, btnStatusSelection);
            var flxSegStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0",
                "clipBounds": false,
                "height": "150px",
                "id": "flxSegStatus",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "sKnflx2C3D73ShadowRoundedBottom",
                "top": "0%",
                "width": "340px",
                "zIndex": 20,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegStatus.setDefaultUnit(kony.flex.DP);
            var segActive = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblUserName": "Active"
                }, {
                    "lblUserName": "Inactive"
                }],
                "groupCells": false,
                "height": "95.53%",
                "id": "segActive",
                "isVisible": true,
                "left": "8dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "segRoundedCornerpx30",
                "rowTemplate": "flxUserList",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": true,
                "showScrollbars": false,
                "top": "11dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxUserList": "flxUserList",
                    "lblUserName": "lblUserName"
                },
                "width": "95.92%",
                "zIndex": 20,
                "appName": "MurahabaLoan"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegStatus.add(segActive);
            flxStatus.add(lblStatus, txtStatus, lstboxstatus, flxStatusSelection, flxSegStatus);
            flxLine3.add(flxUserId, flxStatus);
            var btnModifyUser = new kony.ui.Button({
                "height": "50dp",
                "id": "btnModifyUser",
                "isVisible": true,
                "left": "273dp",
                "skin": "sknbtn2c3d73Rounded18px",
                "text": "Save",
                "top": "70dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUserDetailsSection.add(flxLine1, flxLine2, flxLine3, btnModifyUser);
            var flxAcknowledgement = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "51.73%",
                "centerY": "48.12%",
                "clipBounds": false,
                "height": "460px",
                "id": "flxAcknowledgement",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxBgWhite30PxRadius",
                "top": "0dp",
                "width": "500px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgement.setDefaultUnit(kony.flex.DP);
            var lblRetailPater1 = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblRetailPater1",
                "isVisible": true,
                "skin": "sknlbl20pxCalibriGrey",
                "text": "RETAIL PATNER PORTAL",
                "top": "15%",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLineSection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "3px",
                "id": "flxLineSection",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxRedLine",
                "top": "21%",
                "width": "33px",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxLineSection.setDefaultUnit(kony.flex.DP);
            flxLineSection.add();
            var lblAcknowledgeMsg = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblAcknowledgeMsg",
                "isVisible": true,
                "skin": "sknlbl2c3d7335pxBold",
                "text": "User data \n successfully updated ",
                "top": "30%",
                "width": "50%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBtn = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxBtn",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "55%",
                "width": "100%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxBtn.setDefaultUnit(kony.flex.DP);
            var flxSep1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "2px",
                "id": "flxSep1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxline6A7E9B",
                "top": "15%",
                "width": "274px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxSep1.setDefaultUnit(kony.flex.DP);
            flxSep1.add();
            var btnContinue = new kony.ui.Button({
                "centerX": "49.99%",
                "height": "50dp",
                "id": "btnContinue",
                "isVisible": true,
                "left": "0",
                "skin": "sknbtnNoBg2C3D73px24",
                "text": "Continue",
                "top": "35%",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBtn.add(flxSep1, btnContinue);
            flxAcknowledgement.add(lblRetailPater1, flxLineSection, lblAcknowledgeMsg, flxBtn);
            flxUserDetails.add(flxTopContent, flxUserDetailsSection, flxAcknowledgement);
            var flxUserNotFound = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "51.73%",
                "centerY": "48.12%",
                "clipBounds": false,
                "height": "460px",
                "id": "flxUserNotFound",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxBgWhite30PxRadius",
                "top": "0dp",
                "width": "500px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserNotFound.setDefaultUnit(kony.flex.DP);
            var CopylblRetailPater0e7f1c5d87bf444 = new kony.ui.Label({
                "centerX": "50%",
                "id": "CopylblRetailPater0e7f1c5d87bf444",
                "isVisible": true,
                "skin": "sknlbl20pxCalibriGrey",
                "text": "RETAIL PATNER PORTAL",
                "top": "15%",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyflxLineSection0a8165898f2df4f = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "3px",
                "id": "CopyflxLineSection0a8165898f2df4f",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxRedLine",
                "top": "21%",
                "width": "33px",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxLineSection0a8165898f2df4f.setDefaultUnit(kony.flex.DP);
            CopyflxLineSection0a8165898f2df4f.add();
            var CopylblRetailPater0cae4042c971b4c = new kony.ui.Label({
                "centerX": "50%",
                "id": "CopylblRetailPater0cae4042c971b4c",
                "isVisible": true,
                "skin": "sknlbl18px6A7E9B",
                "text": "Please Search with correct User ID, \nMobile Number or Email ID ",
                "top": "256dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopylblAcknowledgeMsg0i178658825624e = new kony.ui.Label({
                "centerX": "50%",
                "id": "CopylblAcknowledgeMsg0i178658825624e",
                "isVisible": true,
                "skin": "sknlbl2c3d7335pxBold",
                "text": "Error \n user not found ",
                "top": "30%",
                "width": "50%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyflxBtn0h178ee0be72f40 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "50dp",
                "clipBounds": false,
                "height": "100dp",
                "id": "CopyflxBtn0h178ee0be72f40",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxBtn0h178ee0be72f40.setDefaultUnit(kony.flex.DP);
            var CopyflxSep0a4bf1c9d611a4c = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "2px",
                "id": "CopyflxSep0a4bf1c9d611a4c",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxline6A7E9B",
                "top": "5%",
                "width": "274px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxSep0a4bf1c9d611a4c.setDefaultUnit(kony.flex.DP);
            CopyflxSep0a4bf1c9d611a4c.add();
            var btnSearchAgain = new kony.ui.Button({
                "centerX": "49.99%",
                "height": "50dp",
                "id": "btnSearchAgain",
                "isVisible": true,
                "left": "0",
                "skin": "sknbtnNoBg2C3D73px24",
                "text": "Search again",
                "top": "35%",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxBtn0h178ee0be72f40.add(CopyflxSep0a4bf1c9d611a4c, btnSearchAgain);
            flxUserNotFound.add(CopylblRetailPater0e7f1c5d87bf444, CopyflxLineSection0a8165898f2df4f, CopylblRetailPater0cae4042c971b4c, CopylblAcknowledgeMsg0i178658825624e, CopyflxBtn0h178ee0be72f40);
            var flxModifiedSucess = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "51.73%",
                "centerY": "48.12%",
                "clipBounds": false,
                "height": "460px",
                "id": "flxModifiedSucess",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxBgWhite30PxRadius",
                "top": "0dp",
                "width": "500px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxModifiedSucess.setDefaultUnit(kony.flex.DP);
            var CopylblRetailPater0b9fca878eb5c4b = new kony.ui.Label({
                "centerX": "50%",
                "id": "CopylblRetailPater0b9fca878eb5c4b",
                "isVisible": true,
                "skin": "sknlbl20pxCalibriGrey",
                "text": "RETAIL PATNER PORTAL",
                "top": "15%",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyflxLineSection0a59f4c8ca7cf4d = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "3px",
                "id": "CopyflxLineSection0a59f4c8ca7cf4d",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxRedLine",
                "top": "21%",
                "width": "33px",
                "zIndex": 1,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxLineSection0a59f4c8ca7cf4d.setDefaultUnit(kony.flex.DP);
            CopyflxLineSection0a59f4c8ca7cf4d.add();
            var CopylblRetailPater0b84c7712ff234a = new kony.ui.Label({
                "centerX": "50%",
                "id": "CopylblRetailPater0b84c7712ff234a",
                "isVisible": false,
                "skin": "sknlbl18px6A7E9B",
                "text": "Please Search with correct User ID, \nMobile Number or Email ID ",
                "top": "256dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopylblAcknowledgeMsg0b2718e85338845 = new kony.ui.Label({
                "centerX": "50%",
                "id": "CopylblAcknowledgeMsg0b2718e85338845",
                "isVisible": true,
                "skin": "sknlbl2c3d7335pxBold",
                "text": "User data \n successfully updated",
                "top": "30%",
                "width": "75%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyflxBtn0f33011ba77044d = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "50dp",
                "clipBounds": false,
                "height": "100dp",
                "id": "CopyflxBtn0f33011ba77044d",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxBtn0f33011ba77044d.setDefaultUnit(kony.flex.DP);
            var CopyflxSep0c7dc2419cf0a49 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "2px",
                "id": "CopyflxSep0c7dc2419cf0a49",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxline6A7E9B",
                "top": "5%",
                "width": "274px",
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxSep0c7dc2419cf0a49.setDefaultUnit(kony.flex.DP);
            CopyflxSep0c7dc2419cf0a49.add();
            var btnMContinue = new kony.ui.Button({
                "centerX": "49.99%",
                "height": "50dp",
                "id": "btnMContinue",
                "isVisible": true,
                "left": "0",
                "skin": "sknbtnNoBg2C3D73px24",
                "text": "Continue",
                "top": "35%",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxBtn0f33011ba77044d.add(CopyflxSep0c7dc2419cf0a49, btnMContinue);
            flxModifiedSucess.add(CopylblRetailPater0b9fca878eb5c4b, CopyflxLineSection0a59f4c8ca7cf4d, CopylblRetailPater0b84c7712ff234a, CopylblAcknowledgeMsg0b2718e85338845, CopyflxBtn0f33011ba77044d);
            flxRightPane.add(imgBg, flxUserSearch, flxUserDetails, flxUserNotFound, flxModifiedSucess);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "HeaderComponentPostLogin": {
                    "height": "100px",
                    "zIndex": 3
                },
                "leftpane.flxCreateNewUser": {
                    "layoutType": kony.flex.FREE_FORM
                },
                "leftpane.flxHomePage": {
                    "top": "150px",
                    "layoutType": kony.flex.FREE_FORM
                },
                "leftpane.lblCreateNewUser": {
                    "left": "48dp",
                    "top": ""
                },
                "leftpane.lblHomePage": {
                    "left": "48dp"
                },
                "leftpane": {
                    "height": "924px",
                    "top": "100px",
                    "width": "300px",
                    "zIndex": 3
                }
            }
            this.add(HeaderComponentPostLogin, leftpane, flxRightPane);
        };
        return [{
            "addWidgets": addWidgetsfrmModifyUser,
            "enabledForIdleTimeout": false,
            "id": "frmModifyUser",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_g9cdd0378599449380e0539232e540a3,
            "preShow": function(eventobject) {
                controller.AS_Form_d43b11de05d444998899d9ca26e841eb(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "MurahabaLoan"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});