define([], function() {
    var ServiceResponse = {
        USER_ATTRIBUTES: ''
    };
    return ServiceResponse;
});