define("Dashboard/frmDashBoard", function() {
    return function(controller) {
        function addWidgetsfrmDashBoard() {
            this.setDefaultUnit(kony.flex.DP);
            var HeaderComponentPostLogin = new com.HeaderComponentPostLogin({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100px",
                "id": "HeaderComponentPostLogin",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slnflxbottomGreyBorder",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "MurahabaLoan",
                "overrides": {
                    "HeaderComponentPostLogin": {
                        "height": "100px",
                        "zIndex": 3
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var leftpane = new com.leftpane({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "89%",
                "id": "leftpane",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "100px",
                "width": "300px",
                "zIndex": 3,
                "appName": "MurahabaLoan",
                "overrides": {
                    "flxCreateNewUser": {
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxHomePage": {
                        "top": "150px",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxLine1": {
                        "isVisible": true
                    },
                    "flxLine2": {
                        "isVisible": false
                    },
                    "lblCreateNewUser": {
                        "isVisible": true,
                        "left": "48dp",
                        "top": "viz.val_cleared"
                    },
                    "lblHomePage": {
                        "left": "48dp"
                    },
                    "leftpane": {
                        "height": "89%",
                        "top": "100px",
                        "width": "300px",
                        "zIndex": 3
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxRightPane = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "89%",
                "id": "flxRightPane",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "300px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "100px",
                "width": "78%",
                "zIndex": 2,
                "appName": "MurahabaLoan"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightPane.setDefaultUnit(kony.flex.DP);
            var imgBg = new kony.ui.Image2({
                "height": "1000px",
                "id": "imgBg",
                "isVisible": true,
                "left": "50px",
                "skin": "slImage",
                "src": "background1x.png",
                "top": "-239dp",
                "width": "1156px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblContent = new kony.ui.Label({
                "id": "lblContent",
                "isVisible": true,
                "left": "72dp",
                "skin": "sknlbl2c3d73px48",
                "text": "Welcome to Mora and % Retail Partner Portal.",
                "top": "138dp",
                "width": "650dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRightPane.add(imgBg, lblContent);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "HeaderComponentPostLogin": {
                    "height": "100px",
                    "zIndex": 3
                },
                "leftpane.flxCreateNewUser": {
                    "layoutType": kony.flex.FREE_FORM
                },
                "leftpane.flxHomePage": {
                    "top": "150px",
                    "layoutType": kony.flex.FREE_FORM
                },
                "leftpane.lblCreateNewUser": {
                    "left": "48dp",
                    "top": ""
                },
                "leftpane.lblHomePage": {
                    "left": "48dp"
                },
                "leftpane": {
                    "height": "89%",
                    "top": "100px",
                    "width": "300px",
                    "zIndex": 3
                }
            }
            this.add(HeaderComponentPostLogin, leftpane, flxRightPane);
        };
        return [{
            "addWidgets": addWidgetsfrmDashBoard,
            "enabledForIdleTimeout": false,
            "id": "frmDashBoard",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "preShow": function(eventobject) {
                controller.AS_Form_e273fde745984eb0bffa86175bd89d28(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "MurahabaLoan"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});