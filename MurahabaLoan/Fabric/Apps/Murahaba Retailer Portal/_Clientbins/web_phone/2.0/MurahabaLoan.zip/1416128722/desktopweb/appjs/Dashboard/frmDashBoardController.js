define("Dashboard/userfrmDashBoardController", ['ServiceResponse'], function(ServiceResponse) {
    return {
        onPreShow: function() {
            var retailername = ServiceResponse.USER_ATTRIBUTES.retailername;
            var dcontent = this.view.lblContent.text;
            dcontent = dcontent.replace("%", retailername);
            this.view.lblContent.text = dcontent;
        }
    };
});
define("Dashboard/frmDashBoardControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Form_e273fde745984eb0bffa86175bd89d28: function AS_Form_e273fde745984eb0bffa86175bd89d28(eventobject) {
        var self = this;
        this.onPreShow();
    }
});
define("Dashboard/frmDashBoardController", ["Dashboard/userfrmDashBoardController", "Dashboard/frmDashBoardControllerActions"], function() {
    var controller = require("Dashboard/userfrmDashBoardController");
    var controllerActions = ["Dashboard/frmDashBoardControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
